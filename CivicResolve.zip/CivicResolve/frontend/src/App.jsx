import React, { useState, useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { 
  Building2, 
  PlusCircle, 
  Sparkles, 
  MapPin, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle,
  CopyCheck,
  ShieldCheck,
  Users,
  Compass,
  ArrowRight,
  TrendingUp,
  HeartHandshake
} from 'lucide-react';
import api from './services/api';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import StatsBanner from './components/StatsBanner';
import FilterBar from './components/FilterBar';
import IssueCard from './components/IssueCard';
import MapView from './components/MapView';
import IssueDetailsModal from './components/IssueDetailsModal';
import ReportIssueModal from './components/ReportIssueModal';
import ProtectedAdminGate from './components/ProtectedAdminGate';
import LoginPage from './pages/LoginPage';
import SignUpPage from './pages/SignUpPage';

function CivicResolveApp() {
  const { user, isAuthenticated, isAdmin } = useAuth();

  const [issues, setIssues] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeView, setActiveView] = useState('citizen'); // 'citizen', 'admin', 'login', 'signup'
  const [viewMode, setViewMode] = useState('grid'); // 'grid', 'map', 'table'
  const [isResetting, setIsResetting] = useState(false);

  // Filters
  const [filters, setFilters] = useState({
    search: '',
    status: 'All',
    category: 'All',
    urgency: 'All',
    sort: 'newest'
  });

  // Modals
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const loadData = useCallback(async () => {
    try {
      const [issuesRes, statsRes] = await Promise.all([
        api.getIssues(filters),
        api.getStats()
      ]);

      if (issuesRes.success) {
        setIssues(issuesRes.data);
      }
      if (statsRes.success) {
        setStats(statsRes.stats);
      }
    } catch (err) {
      console.error('Failed to load platform data:', err);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleUpvote = async (issueId, email = '') => {
    try {
      const res = await api.upvoteIssue(issueId, email);
      if (res.success) {
        showToast(res.message, res.alreadyUpvoted ? 'info' : 'success');
        loadData();
        return res.data;
      }
    } catch (err) {
      console.error(err);
    }
    return null;
  };

  const handleIssueCreated = (newIssue) => {
    showToast(`Complaint #${newIssue.id} submitted! AI routed to ${newIssue.department}.`);
    loadData();
  };

  const handleStatusUpdated = (updated) => {
    showToast(`Ticket #${updated.id} status updated to ${updated.status}.`);
    loadData();
  };

  const handleResetDemo = async () => {
    if (isResetting) return;
    setIsResetting(true);
    try {
      const res = await api.resetDemoData();
      if (res.success) {
        showToast('Demo data restored to initial state!', 'info');
        await loadData();
      } else {
        showToast(res.error || 'Only administrators can reset demo data', 'info');
      }
    } catch (err) {
      showToast('Error resetting demo data', 'error');
    } finally {
      setIsResetting(false);
    }
  };

  // Dedicated Login Page view
  if (activeView === 'login') {
    return (
      <LoginPage
        onNavigate={(targetView) => setActiveView(targetView)}
        redirectView="citizen"
      />
    );
  }

  // Dedicated Sign Up Page view
  if (activeView === 'signup') {
    return (
      <SignUpPage
        onNavigate={(targetView) => setActiveView(targetView)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-brand-500 selection:text-white">
      
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className={`px-4 py-3 rounded-2xl shadow-xl border flex items-center space-x-2.5 text-xs font-semibold ${
            toast.type === 'info'
              ? 'bg-slate-900 text-white border-slate-700'
              : 'bg-emerald-600 text-white border-emerald-500'
          }`}>
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Navigation Header */}
      <Navbar
        activeView={activeView}
        setActiveView={setActiveView}
        onOpenReportModal={() => setIsReportModalOpen(true)}
        onResetDemo={handleResetDemo}
        stats={stats}
        isResetting={isResetting}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        
        {/* VIEW: CITIZEN PORTAL */}
        {activeView === 'citizen' && (
          <div className="space-y-6">
            
            {/* Hero Banner with Callout */}
            <div className="relative rounded-3xl bg-gradient-to-r from-brand-900 via-brand-800 to-slate-900 text-white p-6 sm:p-10 overflow-hidden shadow-xl border border-brand-800/60">
              <div className="relative z-10 max-w-2xl space-y-3">
                <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs font-medium text-brand-200">
                  <Sparkles className="w-3.5 h-3.5 text-brand-300" />
                  <span>Real-Time AI Classification & Proximity Deduplication</span>
                </div>
                <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
                  Voice your civic concern.<br />
                  <span className="text-brand-300">Resolved with AI precision.</span>
                </h1>
                <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                  Report potholes, broken streetlights, water main leaks, or park hazards. Our AI engine instantly assesses urgency, prevents duplicate dispatches, and routes directly to city crews.
                </p>
                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => setIsReportModalOpen(true)}
                    className="flex items-center space-x-2 px-5 py-2.5 rounded-xl text-sm font-bold bg-white text-brand-900 hover:bg-brand-50 shadow-md shadow-black/20 hover:scale-[1.02] active:scale-95 transition-all"
                  >
                    <PlusCircle className="w-4 h-4 text-brand-600" />
                    <span>Report a Civic Issue Now</span>
                  </button>
                  <button
                    onClick={() => setViewMode('map')}
                    className="flex items-center space-x-2 px-4 py-2.5 rounded-xl text-sm font-semibold bg-white/10 hover:bg-white/20 text-white border border-white/20 backdrop-blur-md transition-all"
                  >
                    <MapPin className="w-4 h-4" />
                    <span>Explore City Map</span>
                  </button>
                </div>
              </div>

              {/* Decorative background circles */}
              <div className="absolute -right-20 -bottom-20 w-80 h-80 rounded-full bg-brand-500/10 blur-3xl pointer-events-none" />
              <div className="absolute right-10 top-5 w-40 h-40 rounded-full bg-sky-400/10 blur-2xl pointer-events-none" />
            </div>

            {/* Platform KPI Banner */}
            <StatsBanner
              stats={stats}
              onFilterStatus={(status) => setFilters(prev => ({ ...prev, status }))}
              currentStatusFilter={filters.status}
            />

            {/* Filter & View Toolbar */}
            <FilterBar
              filters={filters}
              setFilters={setFilters}
              viewMode={viewMode}
              setViewMode={setViewMode}
              counts={{
                total: stats?.total,
                reported: stats?.reported,
                inProgress: stats?.inProgress,
                resolved: stats?.resolved
              }}
            />

            {/* Issues Content: Grid Cards, Map, or Table */}
            {loading ? (
              <div className="py-20 text-center space-y-3">
                <div className="w-8 h-8 border-3 border-brand-500 border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="text-xs text-slate-500 font-medium">Loading civic incidents...</p>
              </div>
            ) : viewMode === 'map' ? (
              <MapView
                issues={issues}
                onSelectIssue={(issue) => setSelectedIssue(issue)}
              />
            ) : viewMode === 'table' ? (
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-200">
                      <th className="py-3 px-4">Ticket</th>
                      <th className="py-3 px-4">Title</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4">Urgency</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Supporters</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {issues.map(iss => (
                      <tr 
                        key={iss.id} 
                        onClick={() => setSelectedIssue(iss)}
                        className="hover:bg-slate-50 cursor-pointer transition-colors"
                      >
                        <td className="py-3 px-4 font-mono font-bold text-slate-800">#{iss.id}</td>
                        <td className="py-3 px-4 font-semibold text-slate-900 max-w-[240px] truncate">{iss.title}</td>
                        <td className="py-3 px-4 text-slate-600">{iss.category}</td>
                        <td className="py-3 px-4 font-bold">
                          <span className={iss.urgency === 'Critical' ? 'text-rose-600' : iss.urgency === 'High' ? 'text-amber-600' : 'text-slate-600'}>
                            {iss.urgency}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                            iss.status === 'Resolved' ? 'bg-emerald-100 text-emerald-800' :
                            iss.status === 'In Progress' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {iss.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-semibold text-slate-700">👍 {iss.upvotes || 1}</td>
                        <td className="py-3 px-4 text-right">
                          <button className="text-brand-600 font-bold hover:underline">View →</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              // Default Grid Cards
              <div>
                {issues.length === 0 ? (
                  <div className="bg-white rounded-3xl border border-dashed border-slate-300 p-12 text-center space-y-4">
                    <Compass className="w-12 h-12 text-slate-400 mx-auto" />
                    <div>
                      <h3 className="text-base font-bold text-slate-800">No civic issues match your criteria</h3>
                      <p className="text-xs text-slate-500 mt-1">Try resetting filters or be the first to report a concern in this area.</p>
                    </div>
                    <button
                      onClick={() => setFilters({ search: '', status: 'All', category: 'All', urgency: 'All', sort: 'newest' })}
                      className="px-4 py-2 text-xs font-bold text-brand-600 bg-brand-50 hover:bg-brand-100 rounded-xl transition-colors"
                    >
                      Clear Filters
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                    {issues.map((issue) => (
                      <IssueCard
                        key={issue.id}
                        issue={issue}
                        onSelect={(iss) => setSelectedIssue(iss)}
                        onUpvote={(id) => handleUpvote(id)}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

          </div>
        )}

        {/* VIEW: PROTECTED CITY STAFF & ADMIN DASHBOARD */}
        {activeView === 'admin' && (
          <ProtectedAdminGate
            issues={issues}
            onSelectIssue={(iss) => setSelectedIssue(iss)}
            onRefresh={loadData}
            stats={stats}
            onNavigate={(targetView) => setActiveView(targetView)}
          />
        )}

      </main>

      {/* Footer */}
      <footer className="mt-12 bg-white border-t border-slate-200 py-6 text-xs text-slate-500 text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 rounded-lg bg-brand-600 flex items-center justify-center text-white text-[10px] font-bold">
              CR
            </div>
            <span className="font-bold text-slate-800">CivicResolve Platform</span>
            <span>• Next-Gen Civic Tech</span>
          </div>
          <p className="text-slate-400">
            Protected by Role-Based Authentication (Citizen, Staff, Admin) & HTTP-Only JWT.
          </p>
        </div>
      </footer>

      {/* Issue Details Modal */}
      {selectedIssue && (
        <IssueDetailsModal
          issue={selectedIssue}
          onClose={() => setSelectedIssue(null)}
          onStatusUpdated={handleStatusUpdated}
          onUpvote={(id) => handleUpvote(id)}
          isAdmin={activeView === 'admin' && isAdmin}
        />
      )}

      {/* Report Issue Modal */}
      {isReportModalOpen && (
        <ReportIssueModal
          isOpen={isReportModalOpen}
          onClose={() => setIsReportModalOpen(false)}
          onIssueCreated={handleIssueCreated}
          onUpvoteIssue={handleUpvote}
          onSelectExistingIssue={(iss) => {
            setIsReportModalOpen(false);
            setSelectedIssue(iss);
          }}
        />
      )}

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CivicResolveApp />
    </AuthProvider>
  );
}
