import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Building2, 
  CopyCheck, 
  Download, 
  Filter, 
  Sparkles, 
  UserCheck, 
  ArrowRight,
  TrendingUp,
  MapPin,
  Eye
} from 'lucide-react';
import api from '../services/api';

export default function AdminTriageView({ 
  issues = [], 
  onSelectIssue, 
  onRefresh, 
  stats 
}) {
  const [clusters, setClusters] = useState([]);
  const [clusterLoading, setClusterLoading] = useState(false);
  const [filterTab, setFilterTab] = useState('all'); // all, critical, unassigned, in_progress, resolved
  const [mergingId, setMergingId] = useState(null);

  // Load citywide duplicate clusters
  useEffect(() => {
    loadClusters();
  }, [issues]);

  const loadClusters = async () => {
    setClusterLoading(true);
    try {
      const res = await api.getClusters();
      if (res.success && res.data) {
        setClusters(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setClusterLoading(false);
    }
  };

  const handleMergeCluster = async (cluster) => {
    const primaryId = cluster.primaryIssue.id;
    const duplicateIds = cluster.issues.filter(i => i.id !== primaryId).map(i => i.id);

    if (duplicateIds.length === 0) return;

    setMergingId(primaryId);
    try {
      const res = await api.mergeDuplicates(
        primaryId, 
        duplicateIds, 
        `Geo-AI auto-consolidated ${duplicateIds.length} nearby complaints into master incident #${primaryId}.`
      );
      if (res.success) {
        confetti({ particleCount: 75, spread: 70, origin: { y: 0.5 } });
        onRefresh();
      }
    } catch (err) {
      console.error(err);
      alert('Error merging duplicates');
    } finally {
      setMergingId(null);
    }
  };

  const handleQuickStatusChange = async (issueId, newStatus) => {
    try {
      const res = await api.updateStatus(issueId, {
        status: newStatus,
        note: `Status updated by Admin to ${newStatus}`,
        updatedBy: 'Operations Dispatcher'
      });
      if (res.success) {
        if (newStatus === 'Resolved') {
          confetti({ particleCount: 60, spread: 50 });
        }
        onRefresh();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const exportCSV = () => {
    const headers = ['ID', 'Title', 'Category', 'Urgency', 'Department', 'Status', 'Upvotes', 'Address', 'Created At'];
    const rows = issues.map(i => [
      i.id,
      `"${(i.title || '').replace(/"/g, '""')}"`,
      i.category,
      i.urgency,
      `"${i.department || ''}"`,
      i.status,
      i.upvotes || 0,
      `"${i.location?.address || ''}"`,
      i.createdAt
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `civicresolve_issues_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered issues for admin triage table
  const filteredIssues = issues.filter(issue => {
    if (filterTab === 'critical') return issue.urgency === 'Critical' && issue.status !== 'Resolved';
    if (filterTab === 'unassigned') return (!issue.assignedOfficer || issue.assignedOfficer === 'Pending Dispatch') && issue.status !== 'Resolved';
    if (filterTab === 'in_progress') return issue.status === 'In Progress';
    if (filterTab === 'resolved') return issue.status === 'Resolved';
    return true;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Admin Header with Export */}
      <div className="bg-gradient-to-r from-slate-900 via-brand-950 to-slate-900 rounded-3xl text-white p-6 sm:p-8 shadow-xl border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-brand-500/20 text-brand-300 border border-brand-500/30">
                Staff Command Portal
              </span>
              <span className="text-xs text-slate-400">Live Municipal Dispatch</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              City Operations & AI Triage Center
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl">
              Monitor incoming civic complaints, review AI priority scores, resolve duplicate report clusters, and dispatch maintenance crews.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={exportCSV}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-semibold border border-white/20 shadow-sm transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Quick Admin KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mt-6 pt-6 border-t border-white/10">
          <div>
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Active Critical</span>
            <div className="text-2xl font-black text-rose-400 mt-0.5">
              {issues.filter(i => i.urgency === 'Critical' && i.status !== 'Resolved').length}
            </div>
          </div>
          <div>
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Crews Deployed</span>
            <div className="text-2xl font-black text-amber-400 mt-0.5">
              {stats?.inProgress || 0}
            </div>
          </div>
          <div>
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Geo Duplicate Clusters</span>
            <div className="text-2xl font-black text-indigo-400 mt-0.5">
              {clusters.length}
            </div>
          </div>
          <div>
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">SLA Adherence</span>
            <div className="text-2xl font-black text-emerald-400 mt-0.5">
              {stats?.slaAdherencePercent || 94.2}%
            </div>
          </div>
        </div>
      </div>

      {/* UNIQUE FEATURE SECTION: GEOGRAPHIC & SEMANTIC DUPLICATE CLUSTERS */}
      {clusters.length > 0 && (
        <div className="bg-gradient-to-r from-indigo-50 via-white to-indigo-50/50 rounded-3xl border-2 border-indigo-200/90 p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center space-x-2.5">
              <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20">
                <CopyCheck className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h3 className="text-base font-bold text-slate-900">
                    AI Duplicate & Incident Clusters
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-100 text-indigo-800 border border-indigo-200">
                    Proximity & Semantic Engine
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  Multiple citizens reported similar incidents in close proximity. Consolidate to streamline crew work orders.
                </p>
              </div>
            </div>
          </div>

          {/* Cluster Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {clusters.map((cluster) => {
              const dupCount = cluster.issues.length - 1;
              const isMerging = mergingId === cluster.primaryIssue.id;

              return (
                <div 
                  key={cluster.clusterId}
                  className="bg-white rounded-2xl border border-indigo-200 p-4 shadow-2xs space-y-3 flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                        {cluster.category}
                      </span>
                      <span className="text-xs font-bold text-slate-600">
                        {cluster.totalReports} Reports • {cluster.totalUpvotes} Citizens Affected
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 line-clamp-1">
                      Primary: #{cluster.primaryIssue.id} — {cluster.primaryIssue.title}
                    </h4>

                    <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs">
                      <span className="text-[11px] font-semibold text-slate-500 block">Nearby Reports in Cluster:</span>
                      {cluster.issues.map((iss, i) => (
                        <div key={i} className="flex items-center justify-between text-slate-700 text-[11px]">
                          <span className="font-mono text-slate-500">#{iss.id}</span>
                          <span className="truncate max-w-[200px] ml-2">{iss.title}</span>
                          <span className="text-slate-400 text-[10px] whitespace-nowrap ml-2">👍 {iss.upvotes || 1}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <button
                      onClick={() => onSelectIssue(cluster.primaryIssue)}
                      className="text-xs font-semibold text-brand-600 hover:text-brand-800 flex items-center"
                    >
                      <Eye className="w-3.5 h-3.5 mr-1" />
                      View Primary Ticket
                    </button>

                    <button
                      onClick={() => handleMergeCluster(cluster)}
                      disabled={isMerging}
                      className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-2xs transition-all active:scale-95 disabled:opacity-50"
                    >
                      <CopyCheck className="w-3.5 h-3.5" />
                      <span>{isMerging ? 'Merging...' : `Merge ${dupCount} Duplicate(s)`}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Staff Triage Table Section */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden">
        
        {/* Table Filter Tabs */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-1 sm:space-x-2 overflow-x-auto">
            {[
              { id: 'all', label: 'All Issues', count: issues.length },
              { id: 'critical', label: 'Critical Emergencies', count: issues.filter(i => i.urgency === 'Critical' && i.status !== 'Resolved').length },
              { id: 'unassigned', label: 'Needs Officer Assignment', count: issues.filter(i => (!i.assignedOfficer || i.assignedOfficer === 'Pending Dispatch') && i.status !== 'Resolved').length },
              { id: 'in_progress', label: 'In Progress', count: issues.filter(i => i.status === 'In Progress').length },
              { id: 'resolved', label: 'Resolved Archive', count: issues.filter(i => i.status === 'Resolved').length }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setFilterTab(tab.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  filterTab === tab.id
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <span>{tab.label}</span>
                <span className="ml-1.5 opacity-70">({tab.count})</span>
              </button>
            ))}
          </div>

          <span className="text-xs text-slate-500 font-medium">
            Showing {filteredIssues.length} tickets
          </span>
        </div>

        {/* Triage Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-bold">
                <th className="py-3 px-4">Ticket</th>
                <th className="py-3 px-4">Subject & Location</th>
                <th className="py-3 px-4">AI Urgency</th>
                <th className="py-3 px-4">Assigned Dept / Officer</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Quick Dispatch Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredIssues.map((issue) => (
                <tr 
                  key={issue.id}
                  onClick={() => onSelectIssue(issue)}
                  className="hover:bg-slate-50/80 cursor-pointer transition-colors"
                >
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-800">
                    #{issue.id}
                  </td>

                  <td className="py-3.5 px-4 max-w-[280px]">
                    <div className="font-bold text-slate-900 truncate">{issue.title}</div>
                    <div className="text-[11px] text-slate-500 flex items-center mt-0.5 truncate">
                      <MapPin className="w-3 h-3 mr-1 text-slate-400 shrink-0" />
                      <span className="truncate">{issue.location?.address}</span>
                    </div>
                  </td>

                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                      issue.urgency === 'Critical' ? 'bg-rose-100 text-rose-800 border border-rose-300' :
                      issue.urgency === 'High' ? 'bg-amber-100 text-amber-800 border border-amber-300' :
                      issue.urgency === 'Medium' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {issue.urgency}
                    </span>
                    <span className="ml-1.5 font-mono text-[11px] text-slate-500">
                      Score: {issue.priorityScore || 50}
                    </span>
                  </td>

                  <td className="py-3.5 px-4 max-w-[200px]">
                    <div className="font-semibold text-slate-800 truncate">{issue.department}</div>
                    <div className="text-[11px] text-slate-500 truncate">
                      Officer: {issue.assignedOfficer || 'Unassigned'}
                    </div>
                  </td>

                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className={`px-2.5 py-0.5 rounded-md font-bold text-[11px] ${
                      issue.status === 'Resolved' ? 'bg-emerald-100 text-emerald-800' :
                      issue.status === 'In Progress' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {issue.status}
                    </span>
                  </td>

                  <td className="py-3.5 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end space-x-1.5">
                      {issue.status === 'Reported' && (
                        <button
                          onClick={() => handleQuickStatusChange(issue.id, 'In Progress')}
                          className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-[11px] shadow-2xs transition-colors"
                          title="Dispatch field crew"
                        >
                          Dispatch Crew
                        </button>
                      )}

                      {issue.status === 'In Progress' && (
                        <button
                          onClick={() => handleQuickStatusChange(issue.id, 'Resolved')}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] shadow-2xs transition-colors"
                          title="Mark Resolved"
                        >
                          Mark Resolved
                        </button>
                      )}

                      <button
                        onClick={() => onSelectIssue(issue)}
                        className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-[11px] border border-slate-200 transition-colors"
                      >
                        Inspect →
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
}
