import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import L from 'leaflet';
import { 
  X, 
  MapPin, 
  Clock, 
  ThumbsUp, 
  Sparkles, 
  ShieldAlert, 
  Building2, 
  CheckCircle2, 
  User, 
  AlertCircle,
  CopyCheck,
  Send,
  FileCheck2,
  Upload,
  ArrowRight
} from 'lucide-react';
import api from '../services/api';
import DuplicateAlertCard from './DuplicateAlertCard';
import { useAuth } from '../context/AuthContext';

export default function IssueDetailsModal({ 
  issue, 
  onClose, 
  onStatusUpdated, 
  onUpvote,
  isAdmin: propIsAdmin = false 
}) {
  const { user, isStaff, isAdmin: authIsAdmin } = useAuth();
  const canManage = propIsAdmin || authIsAdmin || isStaff;

  const [currentIssue, setCurrentIssue] = useState(issue);
  const [nearby, setNearby] = useState([]);
  const [upvoting, setUpvoting] = useState(false);

  // Admin form state
  const [newStatus, setNewStatus] = useState(issue?.status || 'Reported');
  const [adminNote, setAdminNote] = useState('');
  const [assignedOfficer, setAssignedOfficer] = useState(issue?.assignedOfficer || user?.name || '');
  const [resolutionNote, setResolutionNote] = useState(issue?.resolutionNote || '');
  const [isUpdating, setIsUpdating] = useState(false);
  const [aiDraftLoading, setAiDraftLoading] = useState(false);

  const miniMapRef = useRef(null);
  const mapInstanceRef = useRef(null);

  // Fetch full details and nearby on mount
  useEffect(() => {
    if (!issue?.id) return;
    api.getIssue(issue.id).then(res => {
      if (res.success && res.data) {
        setCurrentIssue(res.data);
        setNewStatus(res.data.status);
        setAssignedOfficer(res.data.assignedOfficer || '');
        setResolutionNote(res.data.resolutionNote || '');
        if (res.nearbyRelated) {
          setNearby(res.nearbyRelated);
        }
      }
    });
  }, [issue?.id]);

  // Initialize mini leaflet map
  useEffect(() => {
    if (!miniMapRef.current || !currentIssue?.location?.latitude) return;

    const lat = currentIssue.location.latitude;
    const lng = currentIssue.location.longitude;

    if (!mapInstanceRef.current) {
      const map = L.map(miniMapRef.current, {
        center: [lat, lng],
        zoom: 15,
        zoomControl: false,
        attributionControl: false
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

      L.marker([lat, lng]).addTo(map)
        .bindPopup(`<b>${currentIssue.title}</b><br>${currentIssue.location.address}`)
        .openPopup();

      mapInstanceRef.current = map;
    } else {
      mapInstanceRef.current.setView([lat, lng], 15);
    }
  }, [currentIssue]);

  if (!currentIssue) return null;

  const handleUpvote = async () => {
    if (upvoting) return;
    setUpvoting(true);
    const updated = await onUpvote(currentIssue.id);
    if (updated) {
      setCurrentIssue(prev => ({ ...prev, upvotes: (prev.upvotes || 0) + 1 }));
    }
    setTimeout(() => setUpvoting(false), 300);
  };

  const handleAdminUpdate = async (e) => {
    e.preventDefault();
    setIsUpdating(true);
    try {
      const payload = {
        status: newStatus,
        note: adminNote || `Status updated to ${newStatus}`,
        assignedOfficer,
        resolutionNote,
        updatedBy: assignedOfficer || 'City Operations Admin'
      };

      const res = await api.updateStatus(currentIssue.id, payload);
      if (res.success && res.data) {
        setCurrentIssue(res.data);
        if (newStatus === 'Resolved') {
          confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
        }
        if (onStatusUpdated) onStatusUpdated(res.data);
        setAdminNote('');
      }
    } catch (err) {
      console.error(err);
      alert('Error updating issue status');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleGenerateAiResponse = async () => {
    setAiDraftLoading(true);
    try {
      const res = await api.getSuggestedReply({
        issue: currentIssue,
        actionType: newStatus.toLowerCase().replace(' ', '_'),
        officerName: assignedOfficer
      });
      if (res.success && res.draftText) {
        setAdminNote(res.draftText);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAiDraftLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[90vh] flex flex-col">
        
        {/* Top Header */}
        <div className="px-6 py-4 bg-white border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <span className="font-mono text-sm font-extrabold px-2.5 py-1 rounded-lg bg-slate-100 text-slate-800 border border-slate-200">
              #{currentIssue.id}
            </span>
            <span className={`px-2.5 py-1 rounded-md text-xs font-bold ${
              currentIssue.status === 'Resolved' ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' :
              currentIssue.status === 'In Progress' ? 'bg-amber-100 text-amber-800 border border-amber-200' :
              'bg-blue-100 text-blue-800 border border-blue-200'
            }`}>
              {currentIssue.status}
            </span>
            <span className={`px-2.5 py-1 rounded-md text-xs font-semibold ${
              currentIssue.urgency === 'Critical' ? 'bg-rose-100 text-rose-800 border border-rose-300' :
              currentIssue.urgency === 'High' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
            }`}>
              {currentIssue.urgency} Urgency
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleUpvote}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                upvoting ? 'bg-brand-100 text-brand-700 scale-105' : 'bg-white text-slate-700 hover:bg-brand-50 border-slate-200'
              }`}
            >
              <ThumbsUp className={`w-3.5 h-3.5 ${upvoting ? 'fill-brand-600' : ''}`} />
              <span>{currentIssue.upvotes || 1} Supporters</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* Main Title & Description */}
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 mb-2">
              {currentIssue.title}
            </h1>
            <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-line">
              {currentIssue.description}
            </p>
          </div>

          {/* Photo Media & Mini-Map */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Primary / Before Photo */}
            {currentIssue.imageUrl ? (
              <div className="rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 relative h-56">
                <img
                  src={currentIssue.imageUrl}
                  alt={currentIssue.title}
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/60 backdrop-blur-xs text-white text-[11px] font-semibold">
                  Reported Photo
                </span>
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-slate-200 flex items-center justify-center h-56 bg-slate-50 text-slate-400 text-xs">
                No photo attached
              </div>
            )}

            {/* Resolved After Photo (if resolved) or Mini Map */}
            {currentIssue.status === 'Resolved' && currentIssue.resolutionImageUrl ? (
              <div className="rounded-2xl overflow-hidden border border-emerald-200 bg-emerald-50 relative h-56">
                <img
                  src={currentIssue.resolutionImageUrl}
                  alt="Resolution Proof"
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-2 left-2 px-2 py-0.5 rounded bg-emerald-700 text-white text-[11px] font-bold flex items-center">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Resolved Verification
                </span>
              </div>
            ) : (
              <div className="rounded-2xl overflow-hidden border border-slate-200 h-56 relative">
                <div ref={miniMapRef} className="w-full h-full" />
                <div className="absolute bottom-2 left-2 right-2 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-lg text-[11px] text-slate-700 font-medium truncate z-[400] shadow-xs">
                  📍 {currentIssue.location?.address}
                </div>
              </div>
            )}

          </div>

          {/* AI Triage Intelligence Card */}
          <div className="rounded-2xl border border-brand-200 bg-gradient-to-r from-brand-50/70 to-slate-50 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-xl bg-brand-600 flex items-center justify-center text-white shadow-2xs">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">AI Triage Intelligence & Routing</h3>
                  <p className="text-[11px] text-slate-500">Autonomous classification & dispatch recommendations</p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-white text-brand-700 font-mono text-xs font-bold border border-brand-200">
                Priority: {currentIssue.priorityScore || 65}/100
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-white rounded-xl border border-slate-200/80 space-y-1">
                <span className="text-slate-500 font-semibold block">Responsible Department:</span>
                <span className="font-bold text-slate-900 text-sm block">
                  {currentIssue.department}
                </span>
                <span className="text-slate-500 text-[11px]">Assigned Officer: {currentIssue.assignedOfficer || 'Pending'}</span>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200/80 space-y-1">
                <span className="text-slate-500 font-semibold block">Urgency Rationale:</span>
                <p className="text-slate-700 text-[11px] leading-relaxed">
                  {currentIssue.urgencyReason || currentIssue.aiAnalysis?.urgencyReason}
                </p>
              </div>
            </div>

            {currentIssue.aiAnalysis?.safetyHazard && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-start space-x-2">
                <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Public Safety Hazard Alert:</span>
                  <p className="text-[11px] mt-0.5">{currentIssue.aiAnalysis.safetyHazardDetails}</p>
                </div>
              </div>
            )}

            {currentIssue.aiAnalysis?.inspectionChecklist && (
              <div className="p-3 rounded-xl bg-white border border-slate-200/80 space-y-1.5 text-xs">
                <span className="font-semibold text-slate-800 block">AI Inspection Checklist:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {currentIssue.aiAnalysis.inspectionChecklist.map((item, idx) => (
                    <div key={idx} className="flex items-center space-x-1.5 text-slate-600 text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-brand-600 shrink-0" />
                      <span className="truncate">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Resolution Note (if present) */}
          {currentIssue.resolutionNote && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs space-y-1.5">
              <div className="flex items-center space-x-1.5 text-emerald-800 font-bold">
                <FileCheck2 className="w-4 h-4" />
                <span>Official Resolution Summary</span>
              </div>
              <p className="text-emerald-900 font-medium leading-relaxed">
                {currentIssue.resolutionNote}
              </p>
            </div>
          )}

          {/* Timeline / Audit Trail */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
              <Clock className="w-4 h-4 text-slate-500" />
              <span>Resolution Progress Timeline</span>
            </h3>

            <div className="relative border-l-2 border-slate-200 ml-4 space-y-5 pb-2">
              {(currentIssue.statusHistory || []).map((step, idx) => (
                <div key={idx} className="relative pl-6">
                  <div className={`absolute -left-[9px] top-0.5 w-4 h-4 rounded-full border-2 border-white shadow-xs ${
                    step.status === 'Resolved' ? 'bg-emerald-500 ring-2 ring-emerald-200' :
                    step.status === 'In Progress' ? 'bg-amber-500 ring-2 ring-amber-200' : 'bg-brand-500 ring-2 ring-brand-200'
                  }`} />
                  <div className="flex items-center justify-between text-xs mb-0.5">
                    <span className="font-bold text-slate-800">{step.status}</span>
                    <span className="text-slate-400 font-mono text-[11px]">
                      {new Date(step.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">{step.note}</p>
                  {step.updatedBy && (
                    <span className="text-[10px] text-slate-400 font-medium">By: {step.updatedBy}</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* NEARBY & DUPLICATE COMPLAINTS (If found nearby) */}
          {nearby.length > 0 && (
            <div className="space-y-3 pt-3 border-t border-slate-200">
              <div className="flex items-center space-x-2 text-slate-900 font-bold text-sm">
                <CopyCheck className="w-4 h-4 text-indigo-600" />
                <span>Nearby & Related Complaints in Vicinity ({nearby.length})</span>
              </div>
              <div className="space-y-2">
                {nearby.map((dup, i) => (
                  <DuplicateAlertCard
                    key={i}
                    duplicate={dup}
                    onUpvoteExisting={onUpvote}
                    compact={true}
                  />
                ))}
              </div>
            </div>
          )}

          {/* ADMIN MANAGEMENT & STATUS UPDATE CONTROLS */}
          {canManage && (
            <div className="rounded-2xl border-2 border-brand-500/40 bg-brand-50/20 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-bold text-slate-900">
                    City Staff & Field Officer Actions
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleGenerateAiResponse}
                  disabled={aiDraftLoading}
                  className="flex items-center space-x-1.5 px-3 py-1 bg-white hover:bg-brand-50 text-brand-700 text-xs font-semibold rounded-lg border border-brand-200 shadow-2xs transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-brand-500" />
                  <span>{aiDraftLoading ? 'Generating...' : 'AI Auto-Draft Update'}</span>
                </button>
              </div>

              <form onSubmit={handleAdminUpdate} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Update Status</label>
                    <select
                      value={newStatus}
                      onChange={(e) => setNewStatus(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold text-slate-800"
                    >
                      <option value="Reported">Reported</option>
                      <option value="In Progress">In Progress (Dispatch Crew)</option>
                      <option value="Resolved">Resolved (Complete)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Assigned Field Officer</label>
                    <input
                      type="text"
                      value={assignedOfficer}
                      onChange={(e) => setAssignedOfficer(e.target.value)}
                      placeholder="e.g. Officer John Davis"
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Status Update Note / Timeline Entry</label>
                  <textarea
                    rows={2}
                    value={adminNote}
                    onChange={(e) => setAdminNote(e.target.value)}
                    placeholder="Enter official action taken or work order note..."
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-800 resize-none"
                  />
                </div>

                {newStatus === 'Resolved' && (
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Final Resolution Details</label>
                    <input
                      type="text"
                      value={resolutionNote}
                      onChange={(e) => setResolutionNote(e.target.value)}
                      placeholder="e.g. Asphalt patch completed. Surface compacted and reopened to traffic."
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-slate-800"
                    />
                  </div>
                )}

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isUpdating}
                    className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition-all shadow-sm"
                  >
                    {isUpdating ? 'Saving...' : 'Apply Status Transition'}
                  </button>
                </div>
              </form>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
