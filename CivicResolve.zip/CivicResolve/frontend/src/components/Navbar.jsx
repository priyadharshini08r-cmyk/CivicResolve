import React, { useState } from 'react';
import { 
  Building2, 
  PlusCircle, 
  ShieldCheck, 
  Users, 
  RotateCcw, 
  Sparkles,
  MapPin,
  Menu,
  X,
  Layers,
  Lock,
  LogOut,
  User,
  LogIn,
  UserPlus
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Navbar({ 
  activeView, 
  setActiveView, 
  onOpenReportModal, 
  onResetDemo, 
  stats,
  isResetting 
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, isAuthenticated, isStaff, isAdmin, logout } = useAuth();

  const handleLogout = async () => {
    await logout();
    if (activeView === 'admin') {
      setActiveView('citizen');
    }
  };

  const getRoleBadge = (role) => {
    switch (role) {
      case 'admin':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'staff':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveView('citizen')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-700 to-brand-500 flex items-center justify-center text-white shadow-md shadow-brand-500/20">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl font-bold tracking-tight text-slate-900 font-sans">
                  Civic<span className="text-brand-600">Resolve</span>
                </span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-brand-50 text-brand-700 border border-brand-200/60">
                  <Sparkles className="w-3 h-3 mr-1 text-brand-500" />
                  AI v2.4
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block">AI-Powered Civic Issue Reporting & Triage</p>
            </div>
          </div>

          {/* Desktop Navigation Modes */}
          <div className="hidden md:flex items-center bg-slate-100/90 p-1 rounded-xl border border-slate-200/60">
            <button
              onClick={() => setActiveView('citizen')}
              className={`flex items-center space-x-2 px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                activeView === 'citizen'
                  ? 'bg-white text-brand-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Citizen Portal</span>
            </button>
            <button
              onClick={() => setActiveView('admin')}
              className={`flex items-center space-x-2 px-4 py-1.5 rounded-lg text-sm font-medium transition-all relative ${
                activeView === 'admin'
                  ? 'bg-white text-brand-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>City Staff & Admin</span>
              
              {/* Lock pill if unauthenticated or not staff/admin */}
              {(!isAuthenticated || (!isStaff && !isAdmin)) && (
                <Lock className="w-3 h-3 text-slate-400 ml-1" />
              )}

              {/* Counter badge for pending issues if staff/admin */}
              {isAuthenticated && (isStaff || isAdmin) && stats?.reported > 0 && (
                <span className="ml-1.5 px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-rose-500 text-white animate-pulse">
                  {stats.reported}
                </span>
              )}
            </button>
          </div>

          {/* Desktop Right Side: Auth Status & Actions */}
          <div className="hidden sm:flex items-center space-x-3">
            
            {/* Authenticated User Status or Guest Links */}
            {isAuthenticated ? (
              <div className="flex items-center space-x-2 pl-2 border-l border-slate-200">
                <div className="flex items-center space-x-2 bg-slate-50 border border-slate-200/80 rounded-xl px-2.5 py-1 text-xs">
                  <div className="w-6 h-6 rounded-lg bg-slate-800 text-white flex items-center justify-center font-bold text-[11px]">
                    {user?.name?.[0]?.toUpperCase() || 'U'}
                  </div>
                  <div className="text-left">
                    <span className="font-bold text-slate-900 block truncate max-w-[120px] leading-tight">
                      {user?.name}
                    </span>
                    <span className={`text-[9px] font-bold px-1 rounded uppercase tracking-wider ${getRoleBadge(user?.role)}`}>
                      {user?.role}
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleLogout}
                  title="Sign Out"
                  className="p-2 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setActiveView('login')}
                  className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-all shadow-2xs"
                >
                  <LogIn className="w-3.5 h-3.5 text-slate-500" />
                  <span>Sign In</span>
                </button>
                <button
                  onClick={() => setActiveView('signup')}
                  className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold text-brand-700 bg-brand-50 hover:bg-brand-100 border border-brand-200 rounded-xl transition-all"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Sign Up</span>
                </button>
              </div>
            )}

            {/* Reset Demo Data (admin only or evaluation) */}
            {isAdmin && (
              <button
                onClick={onResetDemo}
                disabled={isResetting}
                title="Reset Demo Data"
                className="flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200"
              >
                <RotateCcw className={`w-3.5 h-3.5 ${isResetting ? 'animate-spin' : ''}`} />
                <span>Reset</span>
              </button>
            )}

            {/* Report Issue CTA */}
            <button
              onClick={onOpenReportModal}
              className="flex items-center space-x-2 px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-brand-600 to-brand-500 hover:from-brand-700 hover:to-brand-600 rounded-xl shadow-md shadow-brand-500/25 hover:shadow-lg transition-all active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Report Issue</span>
            </button>
          </div>

          {/* Mobile Navigation Header */}
          <div className="flex md:hidden items-center space-x-2">
            <button
              onClick={onOpenReportModal}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-brand-600 rounded-lg"
            >
              + Report
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-4 space-y-2">
          
          {/* Mobile User Profile or Login */}
          {isAuthenticated ? (
            <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200 mb-2">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-lg bg-slate-800 text-white flex items-center justify-center font-bold text-xs">
                  {user?.name?.[0]?.toUpperCase()}
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">{user?.name}</div>
                  <div className="text-[10px] text-slate-500 capitalize">{user?.role}</div>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="text-xs font-semibold text-rose-600 hover:underline flex items-center space-x-1"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Logout</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2 mb-2">
              <button
                onClick={() => { setActiveView('login'); setMobileMenuOpen(false); }}
                className="py-2 text-center text-xs font-bold text-slate-700 bg-slate-100 rounded-xl"
              >
                Sign In
              </button>
              <button
                onClick={() => { setActiveView('signup'); setMobileMenuOpen(false); }}
                className="py-2 text-center text-xs font-bold text-brand-700 bg-brand-50 border border-brand-200 rounded-xl"
              >
                Sign Up
              </button>
            </div>
          )}

          <button
            onClick={() => { setActiveView('citizen'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm ${
              activeView === 'citizen' ? 'bg-brand-50 text-brand-700 font-semibold' : 'text-slate-700'
            }`}
          >
            <span className="flex items-center space-x-2">
              <Users className="w-4 h-4" />
              <span>Citizen Portal</span>
            </span>
          </button>
          
          <button
            onClick={() => { setActiveView('admin'); setMobileMenuOpen(false); }}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm ${
              activeView === 'admin' ? 'bg-brand-50 text-brand-700 font-semibold' : 'text-slate-700'
            }`}
          >
            <span className="flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4" />
              <span>City Staff & Admin</span>
            </span>
            {(!isAuthenticated || (!isStaff && !isAdmin)) && (
              <Lock className="w-3.5 h-3.5 text-slate-400" />
            )}
          </button>
        </div>
      )}
    </header>
  );
}
