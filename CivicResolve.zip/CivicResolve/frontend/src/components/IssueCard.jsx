import React, { useState } from 'react';
import { 
  MapPin, 
  ThumbsUp, 
  Clock, 
  Sparkles, 
  ShieldAlert, 
  ChevronRight, 
  CopyCheck,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { CATEGORIES } from '../data/categories';

export default function IssueCard({ issue, onSelect, onUpvote }) {
  const [upvoting, setUpvoting] = useState(false);

  const categoryMeta = CATEGORIES.find(c => c.id === issue.category) || {
    badge: 'bg-slate-100 text-slate-700',
    name: issue.category
  };

  const getUrgencyBadge = (urgency) => {
    switch (urgency) {
      case 'Critical':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-600 mr-1.5 animate-ping" />
            Critical Urgency
          </span>
        );
      case 'High':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-300">
            High Priority
          </span>
        );
      case 'Medium':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-blue-100 text-blue-800 border border-blue-200">
            Medium
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
            Low
          </span>
        );
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Resolved':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-bold bg-emerald-600 text-white shadow-xs">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Resolved
          </span>
        );
      case 'In Progress':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-bold bg-amber-500 text-white shadow-xs">
            <Clock className="w-3 h-3 mr-1" />
            In Progress
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-bold bg-blue-600 text-white shadow-xs">
            <AlertCircle className="w-3 h-3 mr-1" />
            Reported
          </span>
        );
    }
  };

  const handleUpvoteClick = async (e) => {
    e.stopPropagation();
    if (upvoting) return;
    setUpvoting(true);
    await onUpvote(issue.id);
    setTimeout(() => setUpvoting(false), 400);
  };

  const timeAgo = (dateStr) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const hours = Math.floor(diff / (1000 * 3600));
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  return (
    <div
      onClick={() => onSelect(issue)}
      className="group bg-white rounded-2xl border border-slate-200/90 hover:border-brand-400/80 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-pointer hover:-translate-y-1"
    >
      {/* Card Header & Media */}
      <div>
        {issue.imageUrl && (
          <div className="relative h-44 w-full bg-slate-100 overflow-hidden">
            <img
              src={issue.imageUrl}
              alt={issue.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />
            
            {/* Top overlay badges */}
            <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
              {getStatusBadge(issue.status)}
              {getUrgencyBadge(issue.urgency)}
            </div>

            {/* Bottom image overlay */}
            <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-white text-xs">
              <span className="font-mono bg-black/40 backdrop-blur-xs px-2 py-0.5 rounded-md">
                #{issue.id}
              </span>
              <span className="bg-black/40 backdrop-blur-xs px-2 py-0.5 rounded-md">
                {timeAgo(issue.createdAt)}
              </span>
            </div>
          </div>
        )}

        <div className="p-4 sm:p-5">
          {/* If no image, render badges on card top */}
          {!issue.imageUrl && (
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <span className="font-mono text-xs font-bold text-slate-400">#{issue.id}</span>
                {getStatusBadge(issue.status)}
              </div>
              {getUrgencyBadge(issue.urgency)}
            </div>
          )}

          {/* Category & AI Department */}
          <div className="flex flex-wrap items-center gap-1.5 mb-2.5">
            <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${categoryMeta.badge}`}>
              {issue.category}
            </span>
            {issue.department && (
              <span className="text-[10px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md truncate max-w-[200px]">
                {issue.department}
              </span>
            )}
          </div>

          {/* Title */}
          <h3 className="text-base font-bold text-slate-900 group-hover:text-brand-600 transition-colors line-clamp-2 leading-snug mb-2">
            {issue.title}
          </h3>

          {/* Description snippet */}
          <p className="text-xs sm:text-sm text-slate-600 line-clamp-2 mb-3">
            {issue.description}
          </p>

          {/* Location info */}
          <div className="flex items-center text-xs text-slate-500 mb-3">
            <MapPin className="w-3.5 h-3.5 mr-1 text-slate-400 shrink-0" />
            <span className="truncate">{issue.location?.address || 'Metro City'}</span>
          </div>

          {/* Duplicate Cluster Badge (if applicable) */}
          {(issue.duplicatesCount > 0 || (issue.duplicateIds && issue.duplicateIds.length > 0)) && (
            <div className="mb-3 px-2.5 py-1.5 rounded-xl bg-indigo-50 border border-indigo-200/80 flex items-center space-x-2 text-indigo-700 text-xs">
              <CopyCheck className="w-4 h-4 text-indigo-600 shrink-0" />
              <span className="font-medium text-[11px]">
                Geo-AI merged {issue.duplicatesCount || issue.duplicateIds.length} duplicate report(s)
              </span>
            </div>
          )}

          {/* Safety Hazard Banner (if applicable) */}
          {issue.aiAnalysis?.safetyHazard && (
            <div className="mb-3 px-2.5 py-1 rounded-lg bg-rose-50 border border-rose-200 flex items-center space-x-1.5 text-rose-700 text-xs">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-600 shrink-0" />
              <span className="text-[11px] font-semibold truncate">Active Safety Hazard</span>
            </div>
          )}
        </div>
      </div>

      {/* Card Footer: Upvote + View Action */}
      <div className="px-4 sm:px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
        <button
          onClick={handleUpvoteClick}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            upvoting ? 'scale-110 bg-brand-100 text-brand-700' : 'bg-white text-slate-700 hover:bg-brand-50 hover:text-brand-600 border border-slate-200'
          }`}
          title="Upvote / Boost this civic issue"
        >
          <ThumbsUp className={`w-3.5 h-3.5 ${upvoting ? 'fill-brand-600 text-brand-600' : ''}`} />
          <span>{issue.upvotes || 1}</span>
          <span className="hidden sm:inline text-slate-400 font-normal">Supporters</span>
        </button>

        <div className="flex items-center text-xs font-semibold text-brand-600 group-hover:translate-x-0.5 transition-transform">
          <span>View Details</span>
          <ChevronRight className="w-4 h-4 ml-0.5" />
        </div>
      </div>

    </div>
  );
}
