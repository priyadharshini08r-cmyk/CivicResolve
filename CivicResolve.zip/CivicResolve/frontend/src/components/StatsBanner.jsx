import React from 'react';
import { 
  AlertCircle, 
  Clock, 
  CheckCircle2, 
  CopyCheck, 
  TrendingUp, 
  ShieldAlert,
  ThumbsUp
} from 'lucide-react';

export default function StatsBanner({ stats, onFilterStatus, currentStatusFilter }) {
  if (!stats) return null;

  const cards = [
    {
      id: 'Reported',
      label: 'Reported Issues',
      count: stats.reported || 0,
      subtext: 'Awaiting crew assignment',
      icon: AlertCircle,
      color: 'blue',
      bgColor: 'bg-blue-50 border-blue-200/80',
      textColor: 'text-blue-700',
      iconBg: 'bg-blue-600 text-white',
      filterVal: 'Reported'
    },
    {
      id: 'In Progress',
      label: 'In Progress',
      count: stats.inProgress || 0,
      subtext: 'Active field units deployed',
      icon: Clock,
      color: 'amber',
      bgColor: 'bg-amber-50 border-amber-200/80',
      textColor: 'text-amber-700',
      iconBg: 'bg-amber-500 text-white',
      filterVal: 'In Progress'
    },
    {
      id: 'Resolved',
      label: 'Resolved Issues',
      count: stats.resolved || 0,
      subtext: `${stats.resolutionRate || 0}% resolution efficiency`,
      icon: CheckCircle2,
      color: 'emerald',
      bgColor: 'bg-emerald-50 border-emerald-200/80',
      textColor: 'text-emerald-700',
      iconBg: 'bg-emerald-600 text-white',
      filterVal: 'Resolved'
    },
    {
      id: 'Duplicates',
      label: 'Duplicate Detections',
      count: stats.duplicatesResolved || 0,
      subtext: 'Merged & upvoted via Geo-AI',
      icon: CopyCheck,
      color: 'indigo',
      bgColor: 'bg-indigo-50 border-indigo-200/80',
      textColor: 'text-indigo-700',
      iconBg: 'bg-indigo-600 text-white',
      highlightBadge: 'AI Unique Feature'
    }
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
      {cards.map((card) => {
        const Icon = card.icon;
        const isSelected = card.filterVal && currentStatusFilter === card.filterVal;

        return (
          <div
            key={card.id}
            onClick={() => card.filterVal && onFilterStatus && onFilterStatus(isSelected ? 'All' : card.filterVal)}
            className={`p-4 rounded-2xl border transition-all duration-200 ${card.bgColor} ${
              card.filterVal ? 'cursor-pointer hover:shadow-md hover:scale-[1.01]' : ''
            } ${isSelected ? 'ring-2 ring-brand-500 shadow-md' : 'shadow-xs'}`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                {card.label}
              </span>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${card.iconBg} shadow-sm`}>
                <Icon className="w-4 h-4" />
              </div>
            </div>

            <div className="flex items-baseline space-x-2">
              <span className={`text-2xl sm:text-3xl font-extrabold tracking-tight ${card.textColor}`}>
                {card.count}
              </span>
              {card.highlightBadge && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 border border-indigo-200">
                  {card.highlightBadge}
                </span>
              )}
            </div>

            <p className="text-xs text-slate-600 mt-1 truncate">
              {card.subtext}
            </p>
          </div>
        );
      })}
    </div>
  );
}
