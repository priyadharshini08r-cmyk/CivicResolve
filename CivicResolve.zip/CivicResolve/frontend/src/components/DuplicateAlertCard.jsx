import React from 'react';
import { 
  AlertTriangle, 
  ThumbsUp, 
  Eye, 
  MapPin, 
  ArrowRight, 
  Sparkles,
  CheckCircle2,
  CopyCheck
} from 'lucide-react';

export default function DuplicateAlertCard({ 
  duplicate, 
  onUpvoteExisting, 
  onViewExisting,
  compact = false 
}) {
  if (!duplicate) return null;
  const { issue, distanceText, similarityScore, matchType, recommendation } = duplicate;

  const isExactOrProbable = similarityScore >= 70;

  return (
    <div className={`rounded-2xl border transition-all duration-300 overflow-hidden ${
      isExactOrProbable 
        ? 'bg-amber-50/80 border-amber-300/80 shadow-md ring-1 ring-amber-300' 
        : 'bg-indigo-50/80 border-indigo-200 shadow-sm'
    }`}>
      
      {/* Alert Header */}
      <div className={`px-4 py-2.5 flex items-center justify-between text-xs font-bold ${
        isExactOrProbable ? 'bg-amber-100 text-amber-900' : 'bg-indigo-100 text-indigo-900'
      }`}>
        <div className="flex items-center space-x-2">
          {isExactOrProbable ? (
            <AlertTriangle className="w-4 h-4 text-amber-600 animate-pulse shrink-0" />
          ) : (
            <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
          )}
          <span>
            {matchType === 'PROBABLE_DUPLICATE' ? '⚠️ Probable Duplicate Complaint Detected Nearby' : '💡 Similar Nearby Complaint Found'}
          </span>
        </div>
        <div className="flex items-center space-x-1.5">
          <span className="px-2 py-0.5 rounded-full bg-white/90 font-mono text-[11px] font-extrabold text-slate-800 shadow-2xs">
            {similarityScore}% Match
          </span>
          <span className="px-2 py-0.5 rounded-full bg-slate-900 text-white text-[10px]">
            {distanceText}
          </span>
        </div>
      </div>

      {/* Body Content */}
      <div className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1 flex-1">
            <div className="flex items-center space-x-2">
              <span className="font-mono text-xs font-bold text-slate-500">#{issue.id}</span>
              <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                issue.status === 'Resolved' ? 'bg-emerald-100 text-emerald-800' :
                issue.status === 'In Progress' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
              }`}>
                {issue.status}
              </span>
              <span className="text-xs text-slate-500 font-medium">{issue.category}</span>
            </div>

            <h4 className="text-sm font-bold text-slate-900 line-clamp-1">
              {issue.title}
            </h4>

            <p className="text-xs text-slate-600 line-clamp-2">
              {issue.description}
            </p>

            <div className="flex items-center text-xs text-slate-500 pt-0.5">
              <MapPin className="w-3.5 h-3.5 mr-1 text-slate-400" />
              <span className="truncate">{issue.location?.address}</span>
            </div>
          </div>

          {issue.imageUrl && (
            <img 
              src={issue.imageUrl} 
              alt={issue.title}
              className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0 shadow-2xs" 
            />
          )}
        </div>

        {/* AI Recommendation Message */}
        <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/60 text-xs text-slate-700 flex items-start space-x-2">
          <CopyCheck className="w-4 h-4 text-brand-600 shrink-0 mt-0.5" />
          <p className="text-[11px] leading-relaxed">
            <strong className="text-slate-900">AI Recommendation: </strong>
            {recommendation}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end space-x-2 pt-1">
          {onViewExisting && (
            <button
              type="button"
              onClick={() => onViewExisting(issue)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 transition-colors"
            >
              View Ticket
            </button>
          )}

          {onUpvoteExisting && (
            <button
              type="button"
              onClick={() => onUpvoteExisting(issue.id)}
              className="flex items-center space-x-1.5 px-4 py-1.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-brand-600 to-brand-500 hover:from-brand-700 hover:to-brand-600 shadow-sm transition-all active:scale-95"
            >
              <ThumbsUp className="w-3.5 h-3.5" />
              <span>Upvote Existing Report (#{issue.id})</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
