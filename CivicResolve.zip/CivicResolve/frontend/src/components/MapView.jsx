import React, { useEffect, useRef } from 'react';
import L from 'leaflet';

export default function MapView({ issues = [], onSelectIssue, selectedIssueId }) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef([]);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Center on Metro City (lat 30.2685, lng -97.744)
    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [30.2685, -97.744],
        zoom: 14,
        zoomControl: true,
        attributionControl: false
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Clear previous markers
    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    // Helper for custom SVG pin
    const createCustomIcon = (urgency, status) => {
      let bg = '#0270c3'; // default blue
      if (status === 'Resolved') bg = '#10b981'; // green
      else if (urgency === 'Critical') bg = '#e11d48'; // rose
      else if (urgency === 'High' || status === 'In Progress') bg = '#f59e0b'; // amber

      const html = `
        <div style="
          width: 34px;
          height: 34px;
          background: ${bg};
          border: 3px solid white;
          border-radius: 50% 50% 50% 0;
          transform: rotate(-45deg);
          box-shadow: 0 4px 10px rgba(0,0,0,0.3);
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        ">
          <div style="
            width: 12px;
            height: 12px;
            background: white;
            border-radius: 50%;
            transform: rotate(45deg);
          "></div>
        </div>
      `;

      return L.divIcon({
        className: 'custom-map-pin',
        html,
        iconSize: [34, 34],
        iconAnchor: [17, 34],
        popupAnchor: [0, -34]
      });
    };

    // Add markers for all issues
    issues.forEach(issue => {
      const lat = issue.location?.latitude;
      const lng = issue.location?.longitude;
      if (!lat || !lng) return;

      const marker = L.marker([lat, lng], {
        icon: createCustomIcon(issue.urgency, issue.status)
      }).addTo(map);

      // Popup content
      const popupHtml = document.createElement('div');
      popupHtml.className = 'p-1 font-sans max-w-[240px]';
      popupHtml.innerHTML = `
        <div style="font-family: inherit;">
          ${issue.imageUrl ? `<img src="${issue.imageUrl}" style="width:100%; height:90px; object-fit:cover; border-radius:8px; margin-bottom:8px;" />` : ''}
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
            <span style="font-size:11px; font-weight:bold; color:#64748b;">#${issue.id}</span>
            <span style="font-size:11px; font-weight:bold; padding:2px 6px; border-radius:4px; background:${issue.status === 'Resolved' ? '#d1fae5; color:#065f46' : issue.status === 'In Progress' ? '#fef3c7; color:#92400e' : '#dbeafe; color:#1e40af'}">
              ${issue.status}
            </span>
          </div>
          <h4 style="font-size:13px; font-weight:700; color:#0f172a; margin:0 0 4px 0; line-height:1.2;">
            ${issue.title}
          </h4>
          <p style="font-size:11px; color:#64748b; margin:0 0 8px 0;">
            📍 ${issue.location?.address || 'Metro Area'}
          </p>
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:11px; font-weight:600; color:#0270c3;">👍 ${issue.upvotes || 1} Supporters</span>
            <button id="view-btn-${issue.id}" style="
              background:#0270c3; 
              color:white; 
              border:none; 
              padding:4px 8px; 
              border-radius:6px; 
              font-size:11px; 
              font-weight:600; 
              cursor:pointer;
            ">
              View Details →
            </button>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml);

      marker.on('popupopen', () => {
        const btn = document.getElementById(`view-btn-${issue.id}`);
        if (btn) {
          btn.onclick = () => onSelectIssue(issue);
        }
      });

      markersRef.current.push(marker);
    });

    // Invalidate map size to prevent rendering grey tiles
    setTimeout(() => {
      map.invalidateSize();
    }, 250);

  }, [issues, onSelectIssue]);

  return (
    <div className="relative w-full h-[580px] bg-slate-100 rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
      <div ref={mapContainerRef} className="w-full h-full" />
      
      {/* Map Legend Overlay */}
      <div className="absolute bottom-4 right-4 z-[400] bg-white/95 backdrop-blur-md p-3 rounded-xl border border-slate-200/90 shadow-md text-xs space-y-2 pointer-events-auto">
        <div className="font-bold text-slate-800 text-[11px] uppercase tracking-wider mb-1">
          Map Legend
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded-full bg-rose-600 shadow-xs" />
          <span className="text-slate-700 font-medium">Critical Emergency</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded-full bg-amber-500 shadow-xs" />
          <span className="text-slate-700 font-medium">In Progress / High</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded-full bg-blue-600 shadow-xs" />
          <span className="text-slate-700 font-medium">Reported</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded-full bg-emerald-600 shadow-xs" />
          <span className="text-slate-700 font-medium">Resolved</span>
        </div>
      </div>
    </div>
  );
}
