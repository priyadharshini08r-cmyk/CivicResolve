import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  X, 
  Sparkles, 
  MapPin, 
  Camera, 
  Upload, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldAlert, 
  Building2, 
  ThumbsUp,
  Info,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import api from '../services/api';
import { CATEGORIES, CITY_LOCATIONS, SAMPLE_CIVIC_TEMPLATES, PRESET_PHOTOS } from '../data/categories';
import DuplicateAlertCard from './DuplicateAlertCard';
import { useAuth } from '../context/AuthContext';

export default function ReportIssueModal({ 
  isOpen, 
  onClose, 
  onIssueCreated,
  onUpvoteIssue,
  onSelectExistingIssue
}) {
  const { user } = useAuth();
  const [step, setStep] = useState(1); // 1: Details & AI, 2: Location & Photo, 3: Review & Submit
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Roads & Infrastructure');
  const [location, setLocation] = useState(CITY_LOCATIONS[0]);
  const [customAddress, setCustomAddress] = useState(CITY_LOCATIONS[0].address);
  const [selectedPhotoUrl, setSelectedPhotoUrl] = useState('');
  const [imageFile, setImageFile] = useState(null);
  const [reportedBy, setReportedBy] = useState(user?.name || '');
  const [contact, setContact] = useState(user?.email || '');

  // Update reporter info if user state updates
  useEffect(() => {
    if (user) {
      if (!reportedBy) setReportedBy(user.name);
      if (!contact) setContact(user.email);
    }
  }, [user]);

  // AI & Duplicate states
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [duplicates, setDuplicates] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCheckingDuplicates, setIsCheckingDuplicates] = useState(false);

  const debounceTimerRef = useRef(null);

  // Trigger AI analysis and Duplicate check when title or description changes
  useEffect(() => {
    if (!title && !description) {
      setAiAnalysis(null);
      setDuplicates([]);
      return;
    }

    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);

    debounceTimerRef.current = setTimeout(async () => {
      // 1. AI Analysis
      setIsAnalyzing(true);
      try {
        const res = await api.analyzeDraft({
          title,
          description,
          userCategory: category,
          location: {
            address: customAddress,
            latitude: location.lat,
            longitude: location.lng
          }
        });
        if (res.success && res.data) {
          setAiAnalysis(res.data);
          if (res.data.category && (!category || category === 'Roads & Infrastructure')) {
            setCategory(res.data.category);
          }
        }
      } catch (err) {
        console.error('AI draft error:', err);
      } finally {
        setIsAnalyzing(false);
      }

      // 2. Duplicate Check
      setIsCheckingDuplicates(true);
      try {
        const dupRes = await api.checkDuplicates({
          title,
          description,
          category,
          latitude: location.lat,
          longitude: location.lng
        });
        if (dupRes.success && dupRes.duplicates) {
          setDuplicates(dupRes.duplicates);
        }
      } catch (err) {
        console.error('Dup check error:', err);
      } finally {
        setIsCheckingDuplicates(false);
      }

    }, 550);

    return () => clearTimeout(debounceTimerRef.current);
  }, [title, description, location, category, customAddress]);

  if (!isOpen) return null;

  // Apply Quick Sample Template
  const applyTemplate = (tmpl) => {
    setTitle(tmpl.title);
    setDescription(tmpl.description);
    setCategory(tmpl.category);
    setLocation(tmpl.location);
    setCustomAddress(tmpl.location.address);
    setSelectedPhotoUrl(tmpl.imageUrl);
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0]);
      setSelectedPhotoUrl(URL.createObjectURL(e.target.files[0]));
    }
  };

  const handleUpvoteExisting = async (issueId) => {
    await onUpvoteIssue(issueId, contact);
    confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
    onClose();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title || !description) return;

    setIsSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('title', title);
      formData.append('description', description);
      formData.append('category', category);
      formData.append('urgency', aiAnalysis?.urgency || 'Medium');
      formData.append('department', aiAnalysis?.department || 'Department of Public Works & Highways');
      formData.append('reportedBy', reportedBy || 'Concerned Citizen');
      formData.append('contact', contact || '');
      formData.append('location', JSON.stringify({
        address: customAddress || location.address,
        latitude: location.lat,
        longitude: location.lng,
        landmark: location.name
      }));

      if (imageFile) {
        formData.append('image', imageFile);
      } else if (selectedPhotoUrl) {
        formData.append('imageUrl', selectedPhotoUrl);
      }

      if (aiAnalysis) {
        formData.append('aiAnalysis', JSON.stringify(aiAnalysis));
      }

      const res = await api.createIssue(formData);
      if (res.success) {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.5 }
        });
        onIssueCreated(res.data);
        onClose();
      } else {
        alert(`Failed to report: ${res.error || 'Server error'}`);
      }
    } catch (err) {
      console.error(err);
      alert('Error submitting complaint');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-brand-900 via-brand-800 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <Sparkles className="w-5 h-5 text-brand-300" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Report a Civic Issue</h2>
              <p className="text-xs text-brand-200">AI auto-classifies urgency and routes to the proper city department</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Demo Pre-fill Bar */}
        <div className="bg-slate-100 border-b border-slate-200 px-6 py-2.5 flex items-center justify-between flex-wrap gap-2 text-xs">
          <span className="font-semibold text-slate-600 flex items-center">
            <Sparkles className="w-3.5 h-3.5 mr-1 text-brand-600" />
            Quick Demo Templates:
          </span>
          <div className="flex flex-wrap items-center gap-1.5">
            {SAMPLE_CIVIC_TEMPLATES.map((tmpl, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => applyTemplate(tmpl)}
                className="px-2.5 py-1 bg-white hover:bg-brand-50 text-slate-700 hover:text-brand-700 font-medium rounded-lg border border-slate-200/80 shadow-2xs transition-colors"
              >
                {tmpl.name}
              </button>
            ))}
          </div>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Column: Form Inputs (7 cols) */}
            <div className="lg:col-span-7 space-y-5">
              
              {/* Title */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Issue Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Deep crater pothole near 4th Ave intersection"
                  className="w-full px-4 py-2.5 bg-slate-50 focus:bg-white text-sm rounded-xl border border-slate-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-hidden font-medium transition-all"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Detailed Description *
                </label>
                <textarea
                  required
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe what happened, any visible danger, damages caused, or surrounding hazards..."
                  className="w-full px-4 py-2.5 bg-slate-50 focus:bg-white text-sm rounded-xl border border-slate-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-hidden transition-all resize-none"
                />
              </div>

              {/* Location Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Civic Location & Street Address *
                </label>
                
                {/* Preset Chips */}
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {CITY_LOCATIONS.slice(0, 5).map((loc, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        setLocation(loc);
                        setCustomAddress(loc.address);
                      }}
                      className={`px-2.5 py-1 text-xs rounded-lg border transition-all ${
                        location.name === loc.name
                          ? 'bg-brand-600 text-white font-semibold border-brand-600 shadow-2xs'
                          : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
                      }`}
                    >
                      {loc.name.split(' (')[0]}
                    </button>
                  ))}
                </div>

                <div className="relative">
                  <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={customAddress}
                    onChange={(e) => setCustomAddress(e.target.value)}
                    placeholder="Enter street address or choose from presets above"
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 focus:bg-white text-xs sm:text-sm rounded-xl border border-slate-200 focus:border-brand-500 outline-hidden"
                  />
                </div>
              </div>

              {/* Category Override */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Category (AI Assisted)
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 text-xs sm:text-sm rounded-xl border border-slate-200 font-medium focus:border-brand-500 outline-hidden"
                  >
                    {CATEGORIES.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Your Name / Contact (Optional)
                  </label>
                  <input
                    type="text"
                    value={reportedBy}
                    onChange={(e) => setReportedBy(e.target.value)}
                    placeholder="e.g. John Doe / citizen@email.com"
                    className="w-full px-3 py-2 bg-slate-50 text-xs sm:text-sm rounded-xl border border-slate-200 outline-hidden"
                  />
                </div>
              </div>

              {/* Photo Evidence */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Photo Evidence
                </label>
                
                {/* Photo presets */}
                <div className="flex items-center space-x-2 overflow-x-auto pb-2">
                  {PRESET_PHOTOS.map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setSelectedPhotoUrl(p.url);
                        setImageFile(null);
                      }}
                      className={`relative w-14 h-14 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                        selectedPhotoUrl === p.url ? 'border-brand-600 ring-2 ring-brand-400' : 'border-slate-200 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={p.url} alt={p.label} className="w-full h-full object-cover" />
                      <span className="absolute inset-x-0 bottom-0 bg-black/60 text-[9px] text-white text-center truncate">
                        {p.label}
                      </span>
                    </button>
                  ))}
                  
                  {/* Upload custom */}
                  <label className="w-14 h-14 rounded-xl border-2 border-dashed border-slate-300 hover:border-brand-500 flex flex-col items-center justify-center cursor-pointer shrink-0 text-slate-400 hover:text-brand-600 bg-slate-50 transition-colors">
                    <Upload className="w-4 h-4" />
                    <span className="text-[9px] font-semibold mt-0.5">Upload</span>
                    <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
                  </label>
                </div>

                {selectedPhotoUrl && (
                  <div className="mt-2 relative rounded-xl overflow-hidden h-28 w-full border border-slate-200">
                    <img src={selectedPhotoUrl} alt="Preview" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => { setSelectedPhotoUrl(''); setImageFile(null); }}
                      className="absolute top-2 right-2 p-1 rounded-full bg-black/60 text-white hover:bg-black"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

            </div>

            {/* Right Column: AI Triage Assistant & DUPLICATE DETECTOR (5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              
              {/* DUPLICATE DETECTOR CARD (HIGHLIGHT FEATURE) */}
              {duplicates.length > 0 && (
                <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-300">
                  <DuplicateAlertCard
                    duplicate={duplicates[0]}
                    onUpvoteExisting={handleUpvoteExisting}
                    onViewExisting={onSelectExistingIssue}
                  />
                  {duplicates.length > 1 && (
                    <p className="text-[11px] text-slate-500 text-center font-medium">
                      + {duplicates.length - 1} other nearby report(s) also found within 500m
                    </p>
                  )}
                </div>
              )}

              {/* REAL-TIME AI ANALYSIS CARD */}
              <div className="rounded-2xl border border-brand-200/90 bg-gradient-to-b from-brand-50/50 via-white to-white p-4 shadow-sm space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-7 h-7 rounded-lg bg-brand-600 flex items-center justify-center text-white shadow-2xs">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-900">
                      Real-Time AI Triage
                    </span>
                  </div>
                  {isAnalyzing ? (
                    <span className="flex items-center text-xs text-brand-600 font-semibold animate-pulse">
                      <span className="w-2 h-2 rounded-full bg-brand-600 mr-1.5 animate-ping" />
                      Analyzing...
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold text-brand-700 bg-brand-100/80 px-2 py-0.5 rounded-full">
                      94% Confidence
                    </span>
                  )}
                </div>

                {aiAnalysis ? (
                  <div className="space-y-3 text-xs">
                    
                    {/* Urgency & Priority */}
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-500">Detected Urgency:</span>
                        <span className={`px-2.5 py-0.5 rounded-full font-bold text-[11px] ${
                          aiAnalysis.urgency === 'Critical' ? 'bg-rose-100 text-rose-800 border border-rose-300' :
                          aiAnalysis.urgency === 'High' ? 'bg-amber-100 text-amber-800 border border-amber-300' :
                          aiAnalysis.urgency === 'Medium' ? 'bg-blue-100 text-blue-800' : 'bg-slate-200 text-slate-700'
                        }`}>
                          {aiAnalysis.urgency}
                        </span>
                      </div>

                      <p className="text-slate-600 text-[11px] leading-relaxed">
                        {aiAnalysis.urgencyReason}
                      </p>

                      <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px]">
                        <span className="text-slate-500">Resolution SLA:</span>
                        <span className="font-bold text-slate-800">{aiAnalysis.estimatedResolutionHours} hours target</span>
                      </div>
                    </div>

                    {/* Department Routing */}
                    <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                      <div className="flex items-center space-x-1.5 text-slate-700 font-semibold">
                        <Building2 className="w-3.5 h-3.5 text-brand-600" />
                        <span>Recommended Department:</span>
                      </div>
                      <p className="font-bold text-slate-900 text-xs">
                        {aiAnalysis.department}
                      </p>
                    </div>

                    {/* Safety Hazard Flag */}
                    {aiAnalysis.safetyHazard && (
                      <div className="p-3 rounded-xl bg-rose-50 border border-rose-200/80 text-rose-800 flex items-start space-x-2">
                        <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold block">Safety Hazard Flagged</span>
                          <span className="text-[11px]">{aiAnalysis.safetyHazardDetails}</span>
                        </div>
                      </div>
                    )}

                    {/* Field Inspection Checklist */}
                    {aiAnalysis.inspectionChecklist && (
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
                        <span className="font-semibold text-slate-700 block">AI Field Action Checklist:</span>
                        <ul className="space-y-1">
                          {aiAnalysis.inspectionChecklist.map((item, i) => (
                            <li key={i} className="flex items-start text-slate-600 text-[11px]">
                              <CheckCircle2 className="w-3 h-3 text-brand-500 mr-1.5 shrink-0 mt-0.5" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                  </div>
                ) : (
                  <div className="p-6 text-center text-slate-400 space-y-2">
                    <Sparkles className="w-8 h-8 mx-auto text-brand-300 animate-bounce" />
                    <p className="text-xs">Type a title or description above to see live AI classification, urgency rating, and municipal routing in real time.</p>
                  </div>
                )}

              </div>

            </div>

          </div>

          {/* Form Actions Footer */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between flex-wrap gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
            >
              Cancel
            </button>

            <div className="flex items-center space-x-3">
              {duplicates.length > 0 && (
                <button
                  type="button"
                  onClick={() => handleUpvoteExisting(duplicates[0].issue.id)}
                  className="flex items-center space-x-1.5 px-4 py-2 text-xs sm:text-sm font-bold text-brand-700 bg-brand-50 hover:bg-brand-100 border border-brand-200 rounded-xl transition-all"
                >
                  <ThumbsUp className="w-4 h-4" />
                  <span>Upvote Existing Report (#{duplicates[0].issue.id})</span>
                </button>
              )}

              <button
                type="submit"
                disabled={isSubmitting || !title || !description}
                className="flex items-center space-x-2 px-6 py-2.5 text-sm font-bold text-white bg-gradient-to-r from-brand-600 to-brand-500 hover:from-brand-700 hover:to-brand-600 rounded-xl shadow-md shadow-brand-500/25 hover:shadow-lg disabled:opacity-50 transition-all"
              >
                {isSubmitting ? (
                  <span>Submitting...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Submit Civic Report</span>
                  </>
                )}
              </button>
            </div>
          </div>

        </form>

      </div>
    </div>
  );
}
