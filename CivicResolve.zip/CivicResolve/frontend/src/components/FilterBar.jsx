import React from 'react';
import { 
  Search, 
  Filter, 
  Map, 
  LayoutGrid, 
  List, 
  X,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { CATEGORIES } from '../data/categories';

export default function FilterBar({
  filters,
  setFilters,
  viewMode,
  setViewMode,
  counts
}) {
  const statusTabs = [
    { id: 'All', label: 'All Issues', count: counts?.total },
    { id: 'Reported', label: 'Reported', count: counts?.reported, dotColor: 'bg-blue-500' },
    { id: 'In Progress', label: 'In Progress', count: counts?.inProgress, dotColor: 'bg-amber-500' },
    { id: 'Resolved', label: 'Resolved', count: counts?.resolved, dotColor: 'bg-emerald-500' }
  ];

  const hasActiveFilters = 
    filters.search || 
    filters.status !== 'All' || 
    filters.category !== 'All' || 
    filters.urgency !== 'All';

  const resetFilters = () => {
    setFilters({
      search: '',
      status: 'All',
      category: 'All',
      urgency: 'All',
      sort: 'newest'
    });
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-3.5 mb-6 space-y-3.5">
      
      {/* Top Row: Search + Category + Urgency + View Toggles */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        
        {/* Search */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={filters.search}
            onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
            placeholder="Search by title, location, street or ticket ID..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-sm rounded-xl border border-slate-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 transition-all outline-hidden text-slate-900 placeholder:text-slate-400"
          />
          {filters.search && (
            <button
              onClick={() => setFilters(prev => ({ ...prev, search: '' }))}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Dropdowns */}
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
          
          {/* Category Dropdown */}
          <select
            value={filters.category}
            onChange={(e) => setFilters(prev => ({ ...prev, category: e.target.value }))}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-700 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-hidden transition-all"
          >
            <option value="All">All Categories</option>
            {CATEGORIES.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>

          {/* Urgency Dropdown */}
          <select
            value={filters.urgency}
            onChange={(e) => setFilters(prev => ({ ...prev, urgency: e.target.value }))}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-700 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-hidden transition-all"
          >
            <option value="All">All Urgency</option>
            <option value="Critical">🔴 Critical</option>
            <option value="High">🟠 High</option>
            <option value="Medium">🟡 Medium</option>
            <option value="Low">🟢 Low</option>
          </select>

          {/* View Mode Toggle */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setViewMode('grid')}
              title="Grid Card View"
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'grid' ? 'bg-white text-brand-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('map')}
              title="Interactive City Map View"
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'map' ? 'bg-white text-brand-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Map className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              title="Compact Table View"
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'table' ? 'bg-white text-brand-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          {hasActiveFilters && (
            <button
              onClick={resetFilters}
              title="Clear all filters"
              className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}

        </div>
      </div>

      {/* Bottom Row: Status Tabs */}
      <div className="flex items-center space-x-1 sm:space-x-2 border-t border-slate-100 pt-3 overflow-x-auto">
        {statusTabs.map((tab) => {
          const isActive = filters.status === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setFilters(prev => ({ ...prev, status: tab.id }))}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {tab.dotColor && (
                <span className={`w-2 h-2 rounded-full ${tab.dotColor}`} />
              )}
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span className={`px-1.5 py-0.2 rounded-full text-[11px] ${
                  isActive ? 'bg-slate-700 text-slate-200' : 'bg-slate-200/80 text-slate-700'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

    </div>
  );
}
