import React from 'react';
import { 
  ShieldAlert, 
  Lock, 
  UserCheck, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  AlertTriangle,
  RotateCcw,
  Building2,
  Users
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import AdminTriageView from './AdminTriageView';

export default function ProtectedAdminGate({ 
  issues, 
  onSelectIssue, 
  onRefresh, 
  stats, 
  onNavigate 
}) {
  const { user, isAuthenticated, isStaff, isAdmin } = useAuth();

  // If user is staff or admin, render the full admin triage view
  if (isAuthenticated && (isStaff || isAdmin)) {
    return (
      <AdminTriageView
        issues={issues}
        onSelectIssue={onSelectIssue}
        onRefresh={onRefresh}
        stats={stats}
      />
    );
  }

  // CASE 1: USER IS LOGGED IN BUT HAS 'CITIZEN' ROLE (ROLE RESTRICTION)
  if (isAuthenticated && !isStaff && !isAdmin) {
    return (
      <div className="max-w-3xl mx-auto py-12 px-4 animate-in fade-in duration-300">
        <div className="bg-white rounded-3xl border border-rose-200/90 shadow-xl overflow-hidden">
          
          <div className="bg-gradient-to-r from-rose-900 via-slate-900 to-rose-950 p-6 sm:p-8 text-white flex items-center space-x-4">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-8 h-8 text-rose-400" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                Access Restricted
              </span>
              <h2 className="text-xl sm:text-2xl font-black mt-1">
                City Staff & Admin Clearance Required
              </h2>
              <p className="text-xs text-rose-200/80 mt-0.5">
                Role authorization verification failed
              </p>
            </div>
          </div>

          <div className="p-6 sm:p-8 space-y-6">
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-2">
              <div className="flex items-center space-x-2 font-bold text-amber-800">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Current Account: {user?.name} ({user?.email})</span>
              </div>
              <p className="leading-relaxed">
                You are currently signed in with a <strong>Citizen</strong> role. The City Operations & Triage Center allows work-order assignments, emergency dispatch, and duplicate merging, which are restricted exclusively to <strong>City Staff</strong> and <strong>Municipal Administrators</strong>.
              </p>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                onClick={() => onNavigate('citizen')}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-colors"
              >
                ← Return to Citizen Portal
              </button>

              <button
                onClick={() => onNavigate('login', 'admin')}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-md transition-all active:scale-95"
              >
                <UserCheck className="w-4 h-4" />
                <span>Switch to Staff / Admin Account</span>
              </button>
            </div>

          </div>

        </div>
      </div>
    );
  }

  // CASE 2: USER IS NOT AUTHENTICATED AT ALL
  return (
    <div className="max-w-3xl mx-auto py-12 px-4 animate-in fade-in duration-300">
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-brand-950 to-slate-900 p-6 sm:p-8 text-white flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-brand-500/20 border border-brand-500/30 flex items-center justify-center shrink-0">
            <Lock className="w-7 h-7 text-brand-300" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-brand-500/20 text-brand-300 border border-brand-500/30">
                Protected Dashboard
              </span>
              <span className="text-xs text-slate-400">Strict Authentication Enforced</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black mt-1">
              City Staff & Admin Authentication Required
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Please sign in with your municipal officer or administrator credentials
            </p>
          </div>
        </div>

        {/* Body Description */}
        <div className="p-6 sm:p-8 space-y-6">
          <p className="text-sm text-slate-600 leading-relaxed">
            The CivicResolve City Operations Center contains municipal emergency controls, active field crew dispatches, SLA breach alerts, and duplicate incident cluster resolution. Access is protected by secure HTTP-only JWT session authentication.
          </p>

          <div className="bg-slate-50 rounded-2xl p-4 sm:p-5 border border-slate-200/80 space-y-3">
            <span className="text-xs font-bold text-slate-700 flex items-center">
              <Sparkles className="w-3.5 h-3.5 text-brand-600 mr-1.5" />
              Available Staff Credentials for Evaluation:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
                <span className="font-bold text-slate-900 block">City Staff (Field Officer)</span>
                <span className="text-slate-500 font-mono text-[11px] block mt-0.5">staff@civicresolve.gov</span>
                <span className="text-slate-400 text-[10px] font-mono">Password: Staff@1234</span>
              </div>
              <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
                <span className="font-bold text-slate-900 block">Municipal Administrator</span>
                <span className="text-slate-500 font-mono text-[11px] block mt-0.5">admin@civicresolve.gov</span>
                <span className="text-slate-400 text-[10px] font-mono">Password: Admin@1234</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              onClick={() => onNavigate('citizen')}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-colors"
            >
              ← Return to Citizen Portal
            </button>

            <button
              onClick={() => onNavigate('login', 'admin')}
              className="w-full sm:w-auto flex items-center justify-center space-x-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-brand-600 to-brand-500 hover:from-brand-700 hover:to-brand-600 text-white text-xs font-bold shadow-md shadow-brand-500/25 transition-all active:scale-95"
            >
              <Lock className="w-4 h-4" />
              <span>Sign In to Access Command Center</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
