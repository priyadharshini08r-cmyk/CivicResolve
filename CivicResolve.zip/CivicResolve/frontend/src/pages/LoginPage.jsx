import React, { useState } from 'react';
import { 
  Building2, 
  Lock, 
  Mail, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  AlertCircle, 
  Sparkles, 
  ShieldCheck, 
  UserCheck, 
  ArrowLeft,
  CheckCircle2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function LoginPage({ onNavigate, redirectView = 'citizen' }) {
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const demoAccounts = [
    {
      role: 'citizen',
      label: 'Citizen Demo',
      email: 'citizen@example.com',
      password: 'Citizen@1234',
      badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      desc: 'Elena Rostova (Citizen reporting & upvoting)'
    },
    {
      role: 'staff',
      label: 'City Staff Demo',
      email: 'staff@civicresolve.gov',
      password: 'Staff@1234',
      badge: 'bg-amber-100 text-amber-800 border-amber-200',
      desc: 'Sarah Jenkins (Public Works Field Officer)'
    },
    {
      role: 'admin',
      label: 'City Admin Demo',
      email: 'admin@civicresolve.gov',
      password: 'Admin@1234',
      badge: 'bg-brand-100 text-brand-800 border-brand-200',
      desc: 'Marcus Vance (City Operations Director)'
    }
  ];

  const handleSelectDemo = (account) => {
    setEmail(account.email);
    setPassword(account.password);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Client-side validations
    if (!email.trim()) {
      setError('Please enter your email address.');
      return;
    }
    if (!password) {
      setError('Please enter your password.');
      return;
    }

    setLoading(true);
    try {
      const res = await login(email, password);
      if (res.success) {
        // If staff or admin and redirectView was admin, go to admin
        if ((res.user.role === 'staff' || res.user.role === 'admin') && redirectView === 'admin') {
          onNavigate('admin');
        } else {
          onNavigate(redirectView || 'citizen');
        }
      } else {
        setError(res.error || 'Invalid email or password.');
      }
    } catch (err) {
      setError('An error occurred during authentication. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      
      {/* Back to portal button */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md px-4 mb-4">
        <button
          onClick={() => onNavigate('citizen')}
          className="inline-flex items-center text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-1.5" />
          <span>Back to Civic Portal</span>
        </button>
      </div>

      {/* Brand Header */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="flex justify-center items-center space-x-3 mb-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-brand-700 to-brand-500 flex items-center justify-center text-white shadow-lg shadow-brand-500/25">
            <Building2 className="w-6 h-6" />
          </div>
        </div>
        <h2 className="text-center text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Sign In to CivicResolve
        </h2>
        <p className="mt-1.5 text-center text-xs sm:text-sm text-slate-600">
          Access your citizen account or municipal staff command center
        </p>
      </div>

      {/* Main Card */}
      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="bg-white py-8 px-6 sm:px-8 rounded-3xl shadow-xl border border-slate-200/90 space-y-6">
          
          {/* Error Banner */}
          {error && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start space-x-2.5 animate-in fade-in duration-200">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{error}</div>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Email */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 focus:bg-white text-sm rounded-xl border border-slate-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-hidden transition-all"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-50 focus:bg-white text-sm rounded-xl border border-slate-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-hidden transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-brand-600 to-brand-500 hover:from-brand-700 hover:to-brand-600 shadow-md shadow-brand-500/25 hover:shadow-lg disabled:opacity-50 transition-all active:scale-[0.99]"
              >
                {loading ? (
                  <span>Authenticating...</span>
                ) : (
                  <>
                    <span>Sign In</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Quick Demo Credentials Selector */}
          <div className="pt-4 border-t border-slate-100 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700 flex items-center">
                <Sparkles className="w-3.5 h-3.5 text-brand-600 mr-1" />
                1-Click Demo Accounts:
              </span>
              <span className="text-[11px] text-slate-400">Click to fill</span>
            </div>

            <div className="grid grid-cols-1 gap-2">
              {demoAccounts.map((account) => (
                <button
                  key={account.role}
                  type="button"
                  onClick={() => handleSelectDemo(account)}
                  className={`p-2.5 rounded-xl border text-left transition-all hover:scale-[1.01] ${
                    email === account.email
                      ? 'border-brand-500 ring-2 ring-brand-500/20 bg-brand-50/50'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-xs font-bold text-slate-900">{account.label}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md border ${account.badge}`}>
                      {account.role.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 truncate font-mono">
                    {account.email} • {account.password}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Link to Sign Up */}
          <div className="pt-2 text-center text-xs text-slate-600">
            <span>Don't have an account yet? </span>
            <button
              type="button"
              onClick={() => onNavigate('signup')}
              className="font-bold text-brand-600 hover:text-brand-800 hover:underline"
            >
              Sign Up as Citizen
            </button>
          </div>

        </div>
      </div>

    </div>
  );
}
