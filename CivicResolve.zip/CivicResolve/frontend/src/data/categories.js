export const CATEGORIES = [
  {
    id: "Roads & Infrastructure",
    name: "Roads & Infrastructure",
    icon: "Truck",
    color: "amber",
    bgLight: "bg-amber-50 text-amber-700 border-amber-200",
    badge: "bg-amber-100 text-amber-800",
    desc: "Potholes, pavement sinkholes, broken sidewalks, manholes & bridge damage"
  },
  {
    id: "Water Supply & Drainage",
    name: "Water Supply & Drainage",
    icon: "Droplets",
    color: "sky",
    bgLight: "bg-sky-50 text-sky-700 border-sky-200",
    badge: "bg-sky-100 text-sky-800",
    desc: "Burst water mains, localized street flooding, choked drains & sewer backups"
  },
  {
    id: "Streetlights & Electrical",
    name: "Streetlights & Electrical",
    icon: "Zap",
    color: "yellow",
    bgLight: "bg-yellow-50 text-yellow-700 border-yellow-200",
    badge: "bg-yellow-100 text-yellow-800",
    desc: "Unlit street fixtures, exposed cables, sparking transformers & dark alleys"
  },
  {
    id: "Sanitation & Waste",
    name: "Sanitation & Waste",
    icon: "Trash2",
    color: "emerald",
    bgLight: "bg-emerald-50 text-emerald-700 border-emerald-200",
    badge: "bg-emerald-100 text-emerald-800",
    desc: "Overflowing commercial dumpsters, missed curbside pickup & illegal dumping"
  },
  {
    id: "Public Parks & Trees",
    name: "Public Parks & Trees",
    icon: "Trees",
    color: "green",
    bgLight: "bg-green-50 text-green-700 border-green-200",
    badge: "bg-green-100 text-green-800",
    desc: "Downed tree limbs, broken park playground equipment & overgrown pathways"
  },
  {
    id: "Traffic & Encroachment",
    name: "Traffic & Encroachment",
    icon: "Navigation",
    color: "indigo",
    bgLight: "bg-indigo-50 text-indigo-700 border-indigo-200",
    badge: "bg-indigo-100 text-indigo-800",
    desc: "Traffic signal blackouts, obstructed crosswalks, damaged signs & illegal parking"
  },
  {
    id: "Public Safety & Health",
    name: "Public Safety & Health",
    icon: "ShieldAlert",
    color: "rose",
    bgLight: "bg-rose-50 text-rose-700 border-rose-200",
    badge: "bg-rose-100 text-rose-800",
    desc: "Vandalism, hazardous materials, excessive commercial noise & public nuisances"
  }
];

export const DEPARTMENTS = [
  "Department of Public Works & Highways",
  "Municipal Solid Waste Management",
  "Municipal Energy & Street Lighting",
  "Water & Sewage Authority",
  "Parks & Recreation Forestry Dept",
  "Transportation & Traffic Engineering",
  "Public Health & Sanitation Bureau"
];

export const CITY_LOCATIONS = [
  { name: "Downtown Public Library (412 Elm St)", lat: 30.2685, lng: -97.7420, address: "412 Elm Street, Downtown Metro" },
  { name: "6th & Congress Intersection", lat: 30.2680, lng: -97.7428, address: "600 Congress Avenue, Downtown" },
  { name: "Riverdale Health Clinic (Oak Ave)", lat: 30.2710, lng: -97.7455, address: "880 Oak Avenue, Riverdale District" },
  { name: "Midtown Elementary School (9th St)", lat: 30.2742, lng: -97.7478, address: "155 West 9th Street, Midtown" },
  { name: "Pine Plaza Food Court Alley", lat: 30.2650, lng: -97.7405, address: "240 Pine Street Alleyway, Market Square" },
  { name: "Riverwalk Pedestrian Bridge", lat: 30.2625, lng: -97.7460, address: "620 Riverfront Boulevard, Riverwalk" },
  { name: "Sunnydale Children's Playscape", lat: 30.2765, lng: -97.7410, address: "710 Sunnydale Park Way, North Park" },
  { name: "Westside Bus Transit Stop #14", lat: 30.2702, lng: -97.7490, address: "310 Maple Avenue, Westside" },
  { name: "Cedar & 3rd Business Block", lat: 30.2668, lng: -97.7465, address: "305 Cedar Street, Downtown" }
];

export const SAMPLE_CIVIC_TEMPLATES = [
  {
    name: "🚧 Severe Road Pothole (Duplicate Demo)",
    title: "Large deep crater on Elm Street broke my rim",
    description: "Deep pothole right near the library on Elm St. Blew out my front tire this morning! Extremely hazardous for scooters and cyclists at dusk.",
    category: "Roads & Infrastructure",
    location: CITY_LOCATIONS[0],
    imageUrl: "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "⚡ Sparking Street Light (Nearby Demo)",
    title: "Flickering street lamp with dangling electrical cables",
    description: "The street light pole right outside Midtown Elementary has dangling unshielded wires sparking whenever gusts hit it.",
    category: "Streetlights & Electrical",
    location: CITY_LOCATIONS[3],
    imageUrl: "https://images.unsplash.com/photo-1508873696983-2df5293cb325?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "💧 Water Main Flooding",
    title: "Flooding across sidewalk from ruptured water pipe",
    description: "Pavement is bubbling up with pressurized water flooding into the street gutter. Pedestrians have to step into traffic to walk past.",
    category: "Water Supply & Drainage",
    location: CITY_LOCATIONS[2],
    imageUrl: "https://images.unsplash.com/photo-1541888946425-d0fbb186f5f8?auto=format&fit=crop&w=800&q=80"
  },
  {
    name: "🗑️ Overflowing Commercial Bins",
    title: "Heaps of uncollected trash rotting in Pine alley",
    description: "Commercial bins behind the food court are overflowing onto the pavement. Stray dogs and rodents are tearing open plastic bags.",
    category: "Sanitation & Waste",
    location: CITY_LOCATIONS[4],
    imageUrl: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=800&q=80"
  }
];

export const PRESET_PHOTOS = [
  { label: "Pothole", url: "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=800&q=80" },
  { label: "Burst Pipe", url: "https://images.unsplash.com/photo-1541888946425-d0fbb186f5f8?auto=format&fit=crop&w=800&q=80" },
  { label: "Streetlight", url: "https://images.unsplash.com/photo-1508873696983-2df5293cb325?auto=format&fit=crop&w=800&q=80" },
  { label: "Trash Overflow", url: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=800&q=80" },
  { label: "Fallen Tree", url: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80" },
  { label: "Traffic Signal", url: "https://images.unsplash.com/photo-1545459720-aac8509eb02c?auto=format&fit=crop&w=800&q=80" }
];
