const API_BASE = '/api';

// Helper for fetch with credentials enabled
const fetchWithCreds = async (url, options = {}) => {
  const defaultOptions = {
    credentials: 'include',
    ...options
  };
  return fetch(url, defaultOptions);
};

export const api = {
  // Authentication
  async login(email, password) {
    const res = await fetchWithCreds(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    return res.json();
  },

  async register(data) {
    const res = await fetchWithCreds(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async logout() {
    const res = await fetchWithCreds(`${API_BASE}/auth/logout`, {
      method: 'POST'
    });
    return res.json();
  },

  async getCurrentUser() {
    try {
      const res = await fetchWithCreds(`${API_BASE}/auth/me`);
      return res.json();
    } catch (err) {
      return { success: false, user: null };
    }
  },

  async getDemoAccounts() {
    const res = await fetchWithCreds(`${API_BASE}/auth/demo-accounts`);
    return res.json();
  },

  // Issues
  async getIssues(params = {}) {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([key, val]) => {
      if (val !== undefined && val !== null && val !== '' && val !== 'All') {
        query.append(key, val);
      }
    });
    const res = await fetchWithCreds(`${API_BASE}/issues?${query.toString()}`);
    return res.json();
  },

  async getIssue(id) {
    const res = await fetchWithCreds(`${API_BASE}/issues/${id}`);
    return res.json();
  },

  async createIssue(formData) {
    const isFormData = formData instanceof FormData;
    const res = await fetchWithCreds(`${API_BASE}/issues`, {
      method: 'POST',
      headers: isFormData ? {} : { 'Content-Type': 'application/json' },
      body: isFormData ? formData : JSON.stringify(formData)
    });
    return res.json();
  },

  async checkDuplicates(data) {
    const res = await fetchWithCreds(`${API_BASE}/issues/check-duplicates`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async upvoteIssue(id, email = '') {
    const res = await fetchWithCreds(`${API_BASE}/issues/${id}/upvote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    return res.json();
  },

  async updateStatus(id, updateData) {
    const isFormData = updateData instanceof FormData;
    const res = await fetchWithCreds(`${API_BASE}/issues/${id}/status`, {
      method: 'PATCH',
      headers: isFormData ? {} : { 'Content-Type': 'application/json' },
      body: isFormData ? updateData : JSON.stringify(updateData)
    });
    return res.json();
  },

  async mergeDuplicates(primaryId, duplicateIds, note = '') {
    const res = await fetchWithCreds(`${API_BASE}/issues/${primaryId}/merge`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ duplicateIds, note })
    });
    return res.json();
  },

  async getClusters() {
    const res = await fetchWithCreds(`${API_BASE}/issues/clusters`);
    return res.json();
  },

  // AI Service
  async analyzeDraft(data) {
    const res = await fetchWithCreds(`${API_BASE}/ai/analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async getSuggestedReply(data) {
    const res = await fetchWithCreds(`${API_BASE}/ai/suggest-reply`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  // Stats & Management
  async getStats() {
    const res = await fetchWithCreds(`${API_BASE}/stats`);
    return res.json();
  },

  async resetDemoData() {
    const res = await fetchWithCreds(`${API_BASE}/stats/reset-demo`, {
      method: 'POST'
    });
    return res.json();
  }
};

export default api;
