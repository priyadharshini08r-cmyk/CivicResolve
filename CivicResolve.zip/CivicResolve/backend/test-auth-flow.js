import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import userStorage from './services/userStorage.js';
import { generateToken } from './middleware/auth.js';
import authRoutes from './routes/auth.js';
import issuesRoutes from './routes/issues.js';
import statsRoutes from './routes/stats.js';

const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(cookieParser());

app.use('/api/auth', authRoutes);
app.use('/api/issues', issuesRoutes);
app.use('/api/stats', statsRoutes);

const server = app.listen(5099, async () => {
  const BASE = 'http://127.0.0.1:5099';
  console.log('🧪 Starting CivicResolve Auth Test Suite on port 5099...\n');

  try {
    // TEST 1: Register citizen with attempt to self-promote to 'admin'
    console.log('--- TEST 1: Register New Citizen (Attempting Malicious Role Escalation) ---');
    const regRes = await fetch(`${BASE}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Test Citizen User',
        email: `citizen_test_${Date.now()}@test.org`,
        password: 'Password@1234',
        confirmPassword: 'Password@1234',
        role: 'admin' // Attempted role escalation
      })
    });
    const regData = await regRes.json();
    console.log('Register HTTP Status:', regRes.status);
    console.log('Registered User Role:', regData.user?.role);
    if (regData.user?.role !== 'citizen') {
      throw new Error('FAIL: User was able to self-assign non-citizen role!');
    }
    console.log('✅ PASS: User was strictly restricted to "citizen" role.\n');

    // TEST 2: Login validation
    console.log('--- TEST 2: Login Verification (Correct & Incorrect Passwords) ---');
    const badLoginRes = await fetch(`${BASE}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'citizen@example.com',
        password: 'IncorrectPassword999'
      })
    });
    console.log('Bad Login Status (Expected 401):', badLoginRes.status);
    if (badLoginRes.status !== 401) throw new Error('FAIL: Bad password was accepted!');

    const goodLoginRes = await fetch(`${BASE}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'citizen@example.com',
        password: 'Citizen@1234'
      })
    });
    const goodLoginData = await goodLoginRes.json();
    console.log('Good Login Status:', goodLoginRes.status);
    console.log('Logged in user:', goodLoginData.user?.name, 'Role:', goodLoginData.user?.role);
    const citizenCookie = goodLoginRes.headers.get('set-cookie');
    console.log('Cookie received:', citizenCookie?.slice(0, 30) + '...');
    if (!citizenCookie || !citizenCookie.includes('HttpOnly')) {
      throw new Error('FAIL: Expected HttpOnly cookie in response!');
    }
    console.log('✅ PASS: Citizen authenticated & HTTP-only cookie set.\n');

    // TEST 3: Access Control on Protected Admin / Staff Endpoint
    console.log('--- TEST 3: Access Control on /api/issues/clusters (Staff/Admin Only) ---');
    
    // Unauthenticated
    const unauthRes = await fetch(`${BASE}/api/issues/clusters`);
    console.log('Unauthenticated access status (Expected 401):', unauthRes.status);
    if (unauthRes.status !== 401) throw new Error('FAIL: Unauthenticated access permitted!');

    // Authenticated as Citizen (Forbidden)
    const citizenAccessRes = await fetch(`${BASE}/api/issues/clusters`, {
      headers: { Cookie: citizenCookie }
    });
    console.log('Citizen access status (Expected 403 Forbidden):', citizenAccessRes.status);
    if (citizenAccessRes.status !== 403) throw new Error('FAIL: Citizen accessed staff endpoint!');
    console.log('✅ PASS: Citizen blocked from staff/admin endpoint with 403.\n');

    // TEST 4: Login as Staff & Access Staff Endpoint
    console.log('--- TEST 4: City Staff Login & Authorized Access ---');
    const staffLoginRes = await fetch(`${BASE}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'staff@civicresolve.gov',
        password: 'Staff@1234'
      })
    });
    const staffCookie = staffLoginRes.headers.get('set-cookie');
    const staffAccessRes = await fetch(`${BASE}/api/issues/clusters`, {
      headers: { Cookie: staffCookie }
    });
    console.log('Staff access status (Expected 200):', staffAccessRes.status);
    if (staffAccessRes.status !== 200) throw new Error('FAIL: Staff was denied access!');
    console.log('✅ PASS: Staff successfully authorized.\n');

    // TEST 5: Admin Exclusive Operations (e.g. Reset Demo Data)
    console.log('--- TEST 5: Admin Exclusive Operations (/api/stats/reset-demo) ---');
    const staffResetRes = await fetch(`${BASE}/api/stats/reset-demo`, {
      method: 'POST',
      headers: { Cookie: staffCookie }
    });
    console.log('Staff reset attempt status (Expected 403 Forbidden):', staffResetRes.status);
    if (staffResetRes.status !== 403) throw new Error('FAIL: Non-admin was permitted to reset data!');

    const adminLoginRes = await fetch(`${BASE}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'admin@civicresolve.gov',
        password: 'Admin@1234'
      })
    });
    const adminCookie = adminLoginRes.headers.get('set-cookie');
    const adminResetRes = await fetch(`${BASE}/api/stats/reset-demo`, {
      method: 'POST',
      headers: { Cookie: adminCookie }
    });
    console.log('Admin reset attempt status (Expected 200 OK):', adminResetRes.status);
    if (adminResetRes.status !== 200) throw new Error('FAIL: Admin reset failed!');
    console.log('✅ PASS: Admin authorized for sensitive operations.\n');

    // TEST 6: Logout
    console.log('--- TEST 6: Logout & Session Invalidation ---');
    const logoutRes = await fetch(`${BASE}/api/auth/logout`, {
      method: 'POST',
      headers: { Cookie: adminCookie }
    });
    const logoutCookie = logoutRes.headers.get('set-cookie');
    console.log('Logout response status:', logoutRes.status);
    console.log('Logout cookie header:', logoutCookie);
    console.log('✅ PASS: Logout clears session cookie.\n');

    console.log('🎉 ALL 6 AUTHENTICATION & SECURITY TESTS PASSED PERFECTLY!\n');
    server.close();
    process.exit(0);
  } catch (err) {
    console.error('❌ TEST FAILED:', err);
    server.close();
    process.exit(1);
  }
});
