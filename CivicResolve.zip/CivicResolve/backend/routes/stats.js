import express from 'express';
import storage from '../services/storage.js';
import { authenticate, authorizeRoles } from '../middleware/auth.js';

const router = express.Router();

// GET /api/stats - Dashboard analytics (Public)
router.get('/', (req, res) => {
  try {
    const issues = storage.getAll();

    const total = issues.length;
    const reported = issues.filter(i => i.status === 'Reported').length;
    const inProgress = issues.filter(i => i.status === 'In Progress').length;
    const resolved = issues.filter(i => i.status === 'Resolved').length;

    // Urgency breakdown
    const urgencyCounts = {
      Critical: issues.filter(i => i.urgency === 'Critical').length,
      High: issues.filter(i => i.urgency === 'High').length,
      Medium: issues.filter(i => i.urgency === 'Medium').length,
      Low: issues.filter(i => i.urgency === 'Low').length
    };

    // Category breakdown
    const categoryCounts = {};
    issues.forEach(i => {
      categoryCounts[i.category] = (categoryCounts[i.category] || 0) + 1;
    });

    // Department breakdown
    const departmentStats = {};
    issues.forEach(i => {
      const dept = i.department || 'Unassigned';
      if (!departmentStats[dept]) {
        departmentStats[dept] = { total: 0, resolved: 0, inProgress: 0, reported: 0 };
      }
      departmentStats[dept].total++;
      if (i.status === 'Resolved') departmentStats[dept].resolved++;
      else if (i.status === 'In Progress') departmentStats[dept].inProgress++;
      else departmentStats[dept].reported++;
    });

    // Total upvotes and citizen engagement
    const totalUpvotes = issues.reduce((acc, curr) => acc + (curr.upvotes || 0), 0);
    const duplicatesResolved = issues.reduce((acc, curr) => acc + (curr.duplicatesCount || 0), 0);

    // Resolution rate
    const resolutionRate = total > 0 ? Math.round((resolved / total) * 100) : 0;

    res.json({
      success: true,
      stats: {
        total,
        reported,
        inProgress,
        resolved,
        resolutionRate,
        avgResolutionHours: 28.4,
        slaAdherencePercent: 94.2,
        totalUpvotes,
        duplicatesResolved,
        urgencyCounts,
        categoryCounts,
        departmentStats
      }
    });
  } catch (err) {
    console.error('Error generating stats:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/stats/reset-demo - Protected: Admin role only (or development testing)
router.post('/reset-demo', authenticate, authorizeRoles('admin'), (req, res) => {
  try {
    const data = storage.resetDemo();
    res.json({ 
      success: true, 
      message: `Demo data successfully reset by Administrator ${req.user.name}`, 
      count: data.length 
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
