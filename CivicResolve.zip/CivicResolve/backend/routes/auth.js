import express from 'express';
import userStorage from '../services/userStorage.js';
import { generateToken, authenticate } from '../middleware/auth.js';

const router = express.Router();

// Email validation helper
const isValidEmail = (email) => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

// Cookie options helper
const getCookieOptions = () => ({
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax',
  maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
});

/**
 * POST /api/auth/register
 * Public citizen registration (strictly forces role = 'citizen')
 */
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, confirmPassword, phone } = req.body;

    // Validation
    if (!name || name.trim().length < 2) {
      return res.status(400).json({
        success: false,
        error: 'Full name is required (at least 2 characters).'
      });
    }

    if (!email || !isValidEmail(email)) {
      return res.status(400).json({
        success: false,
        error: 'A valid email address is required.'
      });
    }

    if (!password || password.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'Password must be at least 6 characters long.'
      });
    }

    if (confirmPassword !== undefined && password !== confirmPassword) {
      return res.status(400).json({
        success: false,
        error: 'Passwords do not match.'
      });
    }

    // Check if email already registered
    const existing = userStorage.findByEmail(email);
    if (existing) {
      return res.status(400).json({
        success: false,
        error: 'An account with this email address already exists. Please log in instead.'
      });
    }

    // IMPORTANT: Users registering via public sign-up are strictly assigned 'citizen' role.
    // Admin and Staff roles cannot be self-assigned.
    const newUser = await userStorage.createUser({
      name,
      email,
      password,
      role: 'citizen',
      phone: phone || ''
    });

    // Generate JWT and set HTTP-only cookie
    const token = generateToken(newUser);
    res.cookie('token', token, getCookieOptions());

    res.status(201).json({
      success: true,
      message: 'Citizen account created successfully!',
      user: newUser
    });
  } catch (err) {
    console.error('[Auth Register Error]', err);
    res.status(500).json({
      success: false,
      error: 'Failed to create account. Please try again.'
    });
  }
});

/**
 * POST /api/auth/login
 * Authenticates credentials with bcrypt and returns secure cookie
 */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Please provide both email and password.'
      });
    }

    const user = userStorage.findByEmail(email);
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password.'
      });
    }

    const isMatch = await userStorage.verifyPassword(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password.'
      });
    }

    const sanitized = userStorage.sanitizeUser(user);
    const token = generateToken(sanitized);

    // Set HTTP-only cookie
    res.cookie('token', token, getCookieOptions());

    res.json({
      success: true,
      message: `Welcome back, ${sanitized.name}!`,
      user: sanitized
    });
  } catch (err) {
    console.error('[Auth Login Error]', err);
    res.status(500).json({
      success: false,
      error: 'Authentication failed. Please try again.'
    });
  }
});

/**
 * POST /api/auth/logout
 * Clears the session HTTP-only cookie
 */
router.post('/logout', (req, res) => {
  res.clearCookie('token', {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production'
  });

  res.json({
    success: true,
    message: 'Logged out successfully.'
  });
});

/**
 * GET /api/auth/me
 * Retrieves current authenticated user session
 */
router.get('/me', authenticate, (req, res) => {
  res.json({
    success: true,
    user: req.user
  });
});

/**
 * GET /api/auth/demo-accounts
 * Returns available accounts for quick testing of all 3 roles
 */
router.get('/demo-accounts', (req, res) => {
  res.json({
    success: true,
    accounts: [
      {
        role: 'citizen',
        title: 'Citizen Account',
        name: 'Elena Rostova',
        email: 'citizen@example.com',
        description: 'Standard citizen reporting, issue tracking, and neighborhood upvotes.'
      },
      {
        role: 'staff',
        title: 'City Staff (Field Officer)',
        name: 'Sarah Jenkins',
        email: 'staff@civicresolve.gov',
        department: 'Department of Public Works & Highways',
        description: 'Authorized to dispatch field crews, manage tickets, and resolve duplicates.'
      },
      {
        role: 'admin',
        title: 'Municipal Administrator',
        name: 'Marcus Vance',
        email: 'admin@civicresolve.gov',
        department: 'Municipal Administration & Oversight',
        description: 'Full supervisory authority: triage queue, cluster merging, system analytics & demo resets.'
      }
    ]
  });
});

export default router;
