import express from 'express';
import aiService from '../services/aiService.js';

const router = express.Router();

// POST /api/ai/analyze - Analyze issue draft in real-time
router.post('/analyze', async (req, res) => {
  try {
    const { title, description, userCategory, location } = req.body;
    if (!title && !description) {
      return res.status(400).json({ success: false, error: 'Title or description required for analysis' });
    }

    const analysis = await aiService.analyzeIssue({
      title,
      description,
      userCategory,
      location
    });

    res.json({ success: true, data: analysis });
  } catch (err) {
    console.error('AI Analysis error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/ai/suggest-reply - Admin response generator
router.post('/suggest-reply', async (req, res) => {
  try {
    const { issue, actionType, officerName } = req.body;
    if (!issue) {
      return res.status(400).json({ success: false, error: 'Issue context required' });
    }

    let draftText = '';
    const officer = officerName || 'Municipal Operations Team';

    if (actionType === 'in_progress') {
      draftText = `Official Update from ${issue.department}: Your complaint regarding "${issue.title}" has been reviewed by ${officer}. A field unit has been dispatched with estimated on-site arrival within 2-4 hours. We appreciate your vigilance in keeping our city safe.`;
    } else if (actionType === 'resolved') {
      draftText = `Resolution Notice: The reported issue "${issue.title}" has been completed and verified by ${officer}. Municipal safety inspection passed. Thank you for using CivicResolve!`;
    } else {
      draftText = `CivicResolve Dispatch Notice: This complaint has been logged and assigned to ${issue.department}. Initial triage priority is ${issue.urgency}.`;
    }

    res.json({ success: true, draftText });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
