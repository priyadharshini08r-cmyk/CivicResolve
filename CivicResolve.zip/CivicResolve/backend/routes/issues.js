import express from 'express';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import storage from '../services/storage.js';
import aiService from '../services/aiService.js';
import duplicateDetector from '../services/duplicateDetector.js';
import { authenticate, authorizeRoles, optionalAuth } from '../middleware/auth.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

// Multer storage for uploaded civic photos
const uploadStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '..', 'uploads'));
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, `civic-${Date.now()}-${Math.round(Math.random() * 1e5)}${ext}`);
  }
});
const upload = multer({
  storage: uploadStorage,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB
});

// GET /api/issues - List with filters (Public)
router.get('/', (req, res) => {
  try {
    const { status, category, urgency, department, search, sort } = req.query;
    const issues = storage.getAll({ status, category, urgency, department, search, sort });
    res.json({ success: true, count: issues.length, data: issues });
  } catch (err) {
    console.error('Error fetching issues:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/issues/check-duplicates - Check duplicates before submission (Public)
router.post('/check-duplicates', (req, res) => {
  try {
    const { title, description, category, latitude, longitude, excludeId } = req.body;
    if (!title && !description) {
      return res.json({ success: true, duplicates: [] });
    }

    const duplicates = duplicateDetector.findDuplicates({
      title,
      description,
      category,
      latitude,
      longitude,
      excludeId
    });

    res.json({
      success: true,
      hasPotentialDuplicates: duplicates.length > 0,
      count: duplicates.length,
      topMatch: duplicates[0] || null,
      duplicates
    });
  } catch (err) {
    console.error('Error checking duplicates:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/issues/clusters - Citywide issue clusters (Protected: Staff & Admin)
router.get('/clusters', authenticate, authorizeRoles('staff', 'admin'), (req, res) => {
  try {
    const clusters = duplicateDetector.detectCitywideClusters();
    res.json({ success: true, count: clusters.length, data: clusters });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/issues/:id - Single issue detail (Public)
router.get('/:id', (req, res) => {
  try {
    const issue = storage.getById(req.params.id);
    if (!issue) {
      return res.status(404).json({ success: false, error: 'Issue not found' });
    }

    // Also fetch any nearby complaints for context
    const nearby = duplicateDetector.findDuplicates({
      title: issue.title,
      description: issue.description,
      category: issue.category,
      latitude: issue.location?.latitude,
      longitude: issue.location?.longitude,
      excludeId: issue.id,
      maxDistanceMeters: 1000
    });

    res.json({ success: true, data: issue, nearbyRelated: nearby });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/issues - Create a new issue (Citizens & Guests with optional auth)
router.post('/', optionalAuth, upload.single('image'), async (req, res) => {
  try {
    const body = req.body;
    let imageUrl = body.imageUrl || '';

    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    }

    // Parse location
    let location = {
      address: body.address || 'Downtown Metro',
      latitude: parseFloat(body.latitude || 30.2672),
      longitude: parseFloat(body.longitude || -97.7431),
      landmark: body.landmark || ''
    };

    if (body.location && typeof body.location === 'string') {
      try {
        location = JSON.parse(body.location);
      } catch (e) {
        // keep fallback
      }
    } else if (body.location && typeof body.location === 'object') {
      location = body.location;
    }

    // Run AI analysis
    let aiAnalysis = null;
    try {
      if (body.aiAnalysis && typeof body.aiAnalysis === 'string') {
        aiAnalysis = JSON.parse(body.aiAnalysis);
      } else if (body.aiAnalysis && typeof body.aiAnalysis === 'object') {
        aiAnalysis = body.aiAnalysis;
      } else {
        aiAnalysis = await aiService.analyzeIssue({
          title: body.title,
          description: body.description,
          userCategory: body.category,
          location
        });
      }
    } catch (err) {
      console.warn('AI analysis error during creation:', err.message);
    }

    // Auto-populate reporter details if user is logged in
    const reportedBy = body.reportedBy || req.user?.name || 'Concerned Citizen';
    const contact = body.contact || req.user?.email || '';

    const newIssue = storage.create({
      title: body.title,
      description: body.description,
      category: body.category || aiAnalysis?.category || 'Roads & Infrastructure',
      subcategory: aiAnalysis?.subcategory || 'Civic Infrastructure Concern',
      location,
      urgency: body.urgency || aiAnalysis?.urgency || 'Medium',
      urgencyReason: aiAnalysis?.urgencyReason || 'Citizen submitted report awaiting review.',
      department: body.department || aiAnalysis?.department || 'Department of Public Works & Highways',
      priorityScore: aiAnalysis?.priorityScore || 60,
      estimatedResolutionHours: aiAnalysis?.estimatedResolutionHours || 48,
      reportedBy,
      contact,
      imageUrl,
      aiAnalysis
    });

    res.status(201).json({ success: true, data: newIssue });
  } catch (err) {
    console.error('Error creating issue:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/issues/:id/upvote - Upvote / Boost complaint
router.post('/:id/upvote', optionalAuth, (req, res) => {
  try {
    const email = req.body.email || req.user?.email || '';
    const result = storage.upvote(req.params.id, email);
    if (!result) {
      return res.status(404).json({ success: false, error: 'Issue not found' });
    }

    res.json({
      success: true,
      data: result.issue,
      alreadyUpvoted: result.alreadyUpvoted,
      message: result.alreadyUpvoted
        ? 'You have already upvoted this complaint!'
        : 'Thank you! Your upvote increased this issue\'s civic priority score.'
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PATCH /api/issues/:id/status - Protected: Staff & Admin only
router.patch('/:id/status', authenticate, authorizeRoles('staff', 'admin'), upload.single('resolutionImage'), (req, res) => {
  try {
    const updateData = { ...req.body };
    if (req.file) {
      updateData.resolutionImageUrl = `/uploads/${req.file.filename}`;
    }

    // Track user who made the status update
    updateData.updatedBy = `${req.user.name} (${req.user.role === 'admin' ? 'Administrator' : 'City Staff'})`;

    const updatedIssue = storage.updateStatus(req.params.id, updateData);
    if (!updatedIssue) {
      return res.status(404).json({ success: false, error: 'Issue not found' });
    }

    res.json({ success: true, data: updatedIssue });
  } catch (err) {
    console.error('Error updating status:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/issues/:id/merge - Protected: Staff & Admin only
router.post('/:id/merge', authenticate, authorizeRoles('staff', 'admin'), (req, res) => {
  try {
    const { duplicateIds, note } = req.body;
    if (!duplicateIds || !Array.isArray(duplicateIds) || duplicateIds.length === 0) {
      return res.status(400).json({ success: false, error: 'duplicateIds array is required' });
    }

    const adminNote = `${note ? note + ' ' : ''}[Merged by ${req.user.name} - ${req.user.role}]`;
    const merged = storage.mergeDuplicates(req.params.id, duplicateIds, adminNote);
    if (!merged) {
      return res.status(404).json({ success: false, error: 'Primary issue not found' });
    }

    res.json({
      success: true,
      data: merged,
      message: `Successfully merged ${duplicateIds.length} duplicate ticket(s) into #${req.params.id}`
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
