import jwt from 'jsonwebtoken';
import userStorage from '../services/userStorage.js';

const JWT_SECRET = process.env.JWT_SECRET || 'civicresolve-ultra-secure-jwt-secret-98421471';
const JWT_EXPIRES_IN = '7d';

/**
 * Generate a signed JWT for an authenticated user
 */
export const generateToken = (user) => {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
};

/**
 * Middleware: Strictly requires valid authentication
 */
export const authenticate = (req, res, next) => {
  try {
    // Read from secure HTTP-only cookie first, then fallback to Bearer header
    let token = req.cookies?.token;

    if (!token && req.headers.authorization) {
      const parts = req.headers.authorization.split(' ');
      if (parts.length === 2 && parts[0] === 'Bearer') {
        token = parts[1];
      }
    }

    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required. Please log in to continue.'
      });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = userStorage.findById(decoded.id);

    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'The account associated with this session no longer exists.'
      });
    }

    req.user = userStorage.sanitizeUser(user);
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        error: 'Session expired. Please log in again.'
      });
    }
    return res.status(401).json({
      success: false,
      error: 'Invalid authentication token.'
    });
  }
};

/**
 * Middleware: Optional authentication (attaches user if present, doesn't block if guest)
 */
export const optionalAuth = (req, res, next) => {
  try {
    let token = req.cookies?.token;
    if (!token && req.headers.authorization) {
      const parts = req.headers.authorization.split(' ');
      if (parts.length === 2 && parts[0] === 'Bearer') {
        token = parts[1];
      }
    }

    if (token) {
      const decoded = jwt.verify(token, JWT_SECRET);
      const user = userStorage.findById(decoded.id);
      if (user) {
        req.user = userStorage.sanitizeUser(user);
      }
    }
  } catch (err) {
    // Ignore invalid token in optional auth
  }
  next();
};

/**
 * Middleware: Role-based authorization guard
 */
export const authorizeRoles = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required.'
      });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        error: `Access denied. This action requires one of the following roles: [${allowedRoles.join(', ')}]. Your current role is: ${req.user.role}.`
      });
    }

    next();
  };
};
