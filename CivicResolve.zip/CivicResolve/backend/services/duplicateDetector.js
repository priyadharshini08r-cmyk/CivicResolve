/**
 * CivicResolve Duplicate & Nearby Complaints Detection Engine
 * Combines Haversine spatial proximity with TF-IDF/Jaccard semantic similarity
 */

import storage from './storage.js';

// Common stopwords to filter out
const STOPWORDS = new Set([
  'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
  'by', 'from', 'up', 'about', 'into', 'over', 'after', 'is', 'are', 'was', 'were',
  'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'this', 'that',
  'these', 'those', 'there', 'here', 'please', 'help', 'need', 'needs', 'city', 'fix',
  'issue', 'problem', 'street', 'road', 'avenue', 'lane', 'near', 'right'
]);

export class DuplicateDetector {
  /**
   * Calculate Haversine distance in meters between two lat/lng points
   */
  getDistanceInMeters(lat1, lon1, lat2, lon2) {
    if (!lat1 || !lon1 || !lat2 || !lon2) return 999999;
    const R = 6371e3; // Earth radius in meters
    const phi1 = (lat1 * Math.PI) / 180;
    const phi2 = (lat2 * Math.PI) / 180;
    const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
    const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
      Math.cos(phi1) * Math.cos(phi2) *
      Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c);
  }

  /**
   * Tokenize and normalize text into meaningful keywords
   */
  tokenize(text = '') {
    if (!text) return new Set();
    const words = text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 2 && !STOPWORDS.has(w));
    return new Set(words);
  }

  /**
   * Calculate Jaccard similarity of two token sets (0.0 to 1.0)
   */
  calculateTokenSimilarity(tokensA, tokensB) {
    if (tokensA.size === 0 || tokensB.size === 0) return 0;
    let intersection = 0;
    for (const token of tokensA) {
      if (tokensB.has(token)) {
        intersection++;
      } else {
        // Partial substring match check (e.g. pothole vs potholes, broken vs broke)
        for (const b of tokensB) {
          if (token.includes(b) || b.includes(token)) {
            intersection += 0.8;
            break;
          }
        }
      }
    }
    const union = tokensA.size + tokensB.size - intersection;
    return union > 0 ? Math.min(1.0, intersection / union) : 0;
  }

  /**
   * Score spatial proximity (0.0 to 1.0)
   */
  calculateProximityScore(distanceMeters) {
    if (distanceMeters <= 50) return 1.0;
    if (distanceMeters <= 200) return 0.9;
    if (distanceMeters <= 500) return 0.7;
    if (distanceMeters <= 1000) return 0.4;
    if (distanceMeters <= 2000) return 0.15;
    return 0;
  }

  /**
   * Detect potential duplicates and nearby complaints for an incoming report
   */
  findDuplicates({
    title = '',
    description = '',
    category = '',
    latitude,
    longitude,
    excludeId = null,
    maxDistanceMeters = 2000,
    minSimilarityThreshold = 40
  }) {
    const allIssues = storage.getAll();
    const queryTokens = this.tokenize(`${title} ${description}`);
    const results = [];

    const lat = parseFloat(latitude);
    const lon = parseFloat(longitude);

    for (const issue of allIssues) {
      if (excludeId && issue.id === excludeId) continue;

      const issueLat = issue.location?.latitude;
      const issueLon = issue.location?.longitude;
      const distanceMeters = this.getDistanceInMeters(lat, lon, issueLat, issueLon);

      if (distanceMeters > maxDistanceMeters) continue;

      // Text similarity
      const targetTokens = this.tokenize(`${issue.title} ${issue.description}`);
      const textSimilarity = this.calculateTokenSimilarity(queryTokens, targetTokens);

      // Proximity score
      const proximityScore = this.calculateProximityScore(distanceMeters);

      // Category match
      const categoryMatch = (category && issue.category && category.toLowerCase() === issue.category.toLowerCase()) ? 0.2 : 0;

      // Combined similarity score (weighted: 45% spatial proximity, 40% text, 15% category)
      let combinedScore = 0;
      if (distanceMeters < 50 && textSimilarity > 0.3) {
        // Virtually exact location with matching subject
        combinedScore = Math.round((proximityScore * 0.5 + textSimilarity * 0.4 + categoryMatch + 0.1) * 100);
      } else {
        combinedScore = Math.round((proximityScore * 0.45 + textSimilarity * 0.40 + categoryMatch) * 100);
      }

      combinedScore = Math.min(99, Math.max(10, combinedScore));

      // Filter results above threshold or very close within 250m with same category
      if (combinedScore >= minSimilarityThreshold || (distanceMeters <= 250 && categoryMatch > 0)) {
        let matchType = 'NEARBY_RELATED';
        let recommendation = 'Nearby issue identified. Citizen may review.';

        if (combinedScore >= 80 || (distanceMeters <= 150 && textSimilarity >= 0.5)) {
          matchType = 'PROBABLE_DUPLICATE';
          recommendation = `High probability of duplicate issue (${combinedScore}% match). Recommend upvoting existing ticket #${issue.id} to boost urgency without duplicate crew dispatch.`;
        } else if (combinedScore >= 65 || distanceMeters <= 100) {
          matchType = 'HIGHLY_SIMILAR';
          recommendation = `Similar issue active ${distanceMeters}m away. Consider boosting #${issue.id}.`;
        }

        results.push({
          issue,
          distanceMeters,
          distanceText: distanceMeters < 1000 ? `${distanceMeters}m away` : `${(distanceMeters / 1000).toFixed(1)}km away`,
          similarityScore: combinedScore,
          textSimilarity: Math.round(textSimilarity * 100),
          matchType,
          recommendation
        });
      }
    }

    // Sort by highest similarity score first, then closest distance
    results.sort((a, b) => b.similarityScore - a.similarityScore || a.distanceMeters - b.distanceMeters);
    return results.slice(0, 6);
  }

  /**
   * Group issues across the entire city into incident clusters for city administration
   */
  detectCitywideClusters(radiusMeters = 400) {
    const issues = storage.getAll().filter(i => i.status !== 'Resolved');
    const clusters = [];
    const visited = new Set();

    for (let i = 0; i < issues.length; i++) {
      const issueA = issues[i];
      if (visited.has(issueA.id)) continue;

      const clusterGroup = [issueA];
      visited.add(issueA.id);

      for (let j = i + 1; j < issues.length; j++) {
        const issueB = issues[j];
        if (visited.has(issueB.id)) continue;

        const dist = this.getDistanceInMeters(
          issueA.location?.latitude,
          issueA.location?.longitude,
          issueB.location?.latitude,
          issueB.location?.longitude
        );

        if (dist <= radiusMeters) {
          // Check if same or compatible category
          if (issueA.category === issueB.category || dist <= 150) {
            clusterGroup.push(issueB);
            visited.add(issueB.id);
          }
        }
      }

      if (clusterGroup.length > 1) {
        clusters.push({
          clusterId: `CLUST-${clusterGroup[0].id}`,
          primaryIssue: clusterGroup[0],
          issues: clusterGroup,
          totalReports: clusterGroup.length,
          totalUpvotes: clusterGroup.reduce((acc, curr) => acc + (curr.upvotes || 0), 0),
          category: clusterGroup[0].category,
          avgLatitude: clusterGroup.reduce((a, c) => a + c.location.latitude, 0) / clusterGroup.length,
          avgLongitude: clusterGroup.reduce((a, c) => a + c.location.longitude, 0) / clusterGroup.length,
          highestUrgency: clusterGroup.some(c => c.urgency === 'Critical') ? 'Critical' :
                          clusterGroup.some(c => c.urgency === 'High') ? 'High' : 'Medium'
        });
      }
    }

    clusters.sort((a, b) => b.totalReports - a.totalReports);
    return clusters;
  }
}

export default new DuplicateDetector();
