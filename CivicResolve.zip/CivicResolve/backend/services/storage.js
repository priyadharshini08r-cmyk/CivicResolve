import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { seedIssues } from '../data/seedData.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_FILE = path.join(__dirname, '..', 'data', 'issues.json');

class StorageService {
  constructor() {
    this.ensureDataFile();
  }

  ensureDataFile() {
    try {
      if (!fs.existsSync(DATA_FILE)) {
        this.saveIssues(seedIssues);
        console.log(`[Storage] Initialized with ${seedIssues.length} seed civic issues.`);
      } else {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        if (!raw.trim()) {
          this.saveIssues(seedIssues);
        }
      }
    } catch (err) {
      console.error('[Storage] Error ensuring data file:', err);
      this.saveIssues(seedIssues);
    }
  }

  loadIssues() {
    try {
      if (!fs.existsSync(DATA_FILE)) {
        this.ensureDataFile();
      }
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      return JSON.parse(raw);
    } catch (err) {
      console.error('[Storage] Failed to read issues file:', err);
      return [...seedIssues];
    }
  }

  saveIssues(issues) {
    try {
      const dir = path.dirname(DATA_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(DATA_FILE, JSON.stringify(issues, null, 2), 'utf-8');
      return true;
    } catch (err) {
      console.error('[Storage] Failed to write issues file:', err);
      return false;
    }
  }

  getAll(filters = {}) {
    let issues = this.loadIssues();

    if (filters.status && filters.status !== 'All') {
      issues = issues.filter(i => i.status.toLowerCase() === filters.status.toLowerCase());
    }

    if (filters.category && filters.category !== 'All') {
      issues = issues.filter(i => i.category.toLowerCase() === filters.category.toLowerCase());
    }

    if (filters.urgency && filters.urgency !== 'All') {
      issues = issues.filter(i => i.urgency.toLowerCase() === filters.urgency.toLowerCase());
    }

    if (filters.department && filters.department !== 'All') {
      issues = issues.filter(i => i.department.toLowerCase() === filters.department.toLowerCase());
    }

    if (filters.search) {
      const term = filters.search.toLowerCase().trim();
      issues = issues.filter(i =>
        i.title.toLowerCase().includes(term) ||
        i.description.toLowerCase().includes(term) ||
        i.id.toLowerCase().includes(term) ||
        (i.location && i.location.address && i.location.address.toLowerCase().includes(term)) ||
        (i.location && i.location.landmark && i.location.landmark.toLowerCase().includes(term))
      );
    }

    // Sort
    const sort = filters.sort || 'newest';
    if (sort === 'newest') {
      issues.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    } else if (sort === 'oldest') {
      issues.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    } else if (sort === 'priority') {
      issues.sort((a, b) => (b.priorityScore || 0) - (a.priorityScore || 0));
    } else if (sort === 'upvotes') {
      issues.sort((a, b) => (b.upvotes || 0) - (a.upvotes || 0));
    }

    return issues;
  }

  getById(id) {
    const issues = this.loadIssues();
    return issues.find(i => i.id === id) || null;
  }

  create(issueData) {
    const issues = this.loadIssues();

    // Generate unique readable ID CR-10xx
    const maxNum = issues.reduce((acc, curr) => {
      const match = curr.id && curr.id.match(/^CR-(\d+)$/);
      if (match) {
        const num = parseInt(match[1], 10);
        return num > acc ? num : acc;
      }
      return acc;
    }, 1012);

    const newId = `CR-${maxNum + 1}`;
    const now = new Date().toISOString();

    const newIssue = {
      id: newId,
      title: issueData.title,
      description: issueData.description,
      category: issueData.category || "Roads & Infrastructure",
      subcategory: issueData.subcategory || "General Public Concern",
      location: {
        address: issueData.location?.address || "Downtown Metro",
        latitude: parseFloat(issueData.location?.latitude || 30.2672),
        longitude: parseFloat(issueData.location?.longitude || -97.7431),
        landmark: issueData.location?.landmark || ""
      },
      urgency: issueData.urgency || "Medium",
      urgencyReason: issueData.urgencyReason || "Reported by citizen for municipal review.",
      department: issueData.department || "Department of Public Works & Highways",
      status: "Reported",
      statusHistory: [
        {
          status: "Reported",
          timestamp: now,
          note: issueData.initialNote || "Report submitted via CivicResolve Citizen Portal.",
          updatedBy: issueData.reportedBy ? `Citizen: ${issueData.reportedBy}` : "Citizen Report"
        }
      ],
      priorityScore: issueData.priorityScore || 50,
      estimatedResolutionHours: issueData.estimatedResolutionHours || 48,
      assignedOfficer: "Pending Dispatch",
      reportedBy: issueData.reportedBy || "Anonymous Citizen",
      contact: issueData.contact || "",
      upvotes: 1,
      upvoterEmails: issueData.contact ? [issueData.contact] : [],
      imageUrl: issueData.imageUrl || "",
      resolutionNote: "",
      resolutionImageUrl: "",
      duplicatesCount: 0,
      duplicateIds: [],
      aiAnalysis: issueData.aiAnalysis || null,
      createdAt: now,
      updatedAt: now
    };

    issues.unshift(newIssue);
    this.saveIssues(issues);
    return newIssue;
  }

  updateStatus(id, updateData) {
    const issues = this.loadIssues();
    const index = issues.findIndex(i => i.id === id);
    if (index === -1) return null;

    const issue = issues[index];
    const now = new Date().toISOString();

    if (updateData.status && updateData.status !== issue.status) {
      issue.status = updateData.status;
      issue.statusHistory.push({
        status: updateData.status,
        timestamp: now,
        note: updateData.note || `Status transitioned to ${updateData.status}`,
        updatedBy: updateData.updatedBy || 'Staff / Admin'
      });
    }

    if (updateData.assignedOfficer !== undefined) {
      issue.assignedOfficer = updateData.assignedOfficer;
    }
    if (updateData.department !== undefined) {
      issue.department = updateData.department;
    }
    if (updateData.urgency !== undefined) {
      issue.urgency = updateData.urgency;
    }
    if (updateData.resolutionNote !== undefined) {
      issue.resolutionNote = updateData.resolutionNote;
    }
    if (updateData.resolutionImageUrl !== undefined) {
      issue.resolutionImageUrl = updateData.resolutionImageUrl;
    }

    issue.updatedAt = now;
    issues[index] = issue;
    this.saveIssues(issues);
    return issue;
  }

  upvote(id, citizenEmail = '') {
    const issues = this.loadIssues();
    const issue = issues.find(i => i.id === id);
    if (!issue) return null;

    // Prevent duplicate upvote from same email if provided
    if (citizenEmail && issue.upvoterEmails?.includes(citizenEmail)) {
      return { issue, alreadyUpvoted: true };
    }

    issue.upvotes = (issue.upvotes || 0) + 1;
    if (citizenEmail) {
      if (!issue.upvoterEmails) issue.upvoterEmails = [];
      issue.upvoterEmails.push(citizenEmail);
    }

    // Boost priority slightly with citizen demand (max 100)
    if (issue.priorityScore < 98) {
      issue.priorityScore = Math.min(100, (issue.priorityScore || 50) + 2);
    }

    issue.updatedAt = new Date().toISOString();
    this.saveIssues(issues);
    return { issue, alreadyUpvoted: false };
  }

  mergeDuplicates(primaryId, duplicateIds = [], adminNote = '') {
    const issues = this.loadIssues();
    const primary = issues.find(i => i.id === primaryId);
    if (!primary) return null;

    let additionalVotes = 0;
    const now = new Date().toISOString();

    duplicateIds.forEach(dupId => {
      const dup = issues.find(i => i.id === dupId);
      if (dup && dup.id !== primaryId) {
        additionalVotes += (dup.upvotes || 1);
        dup.status = 'Resolved';
        dup.resolutionNote = `Merged into primary incident #${primaryId}.`;
        dup.statusHistory.push({
          status: 'Resolved',
          timestamp: now,
          note: `Complaint merged into parent ticket #${primaryId}. ${adminNote}`,
          updatedBy: 'Admin Duplicate Resolver'
        });
        if (!primary.duplicateIds.includes(dup.id)) {
          primary.duplicateIds.push(dup.id);
        }
      }
    });

    primary.upvotes = (primary.upvotes || 0) + additionalVotes;
    primary.duplicatesCount = (primary.duplicatesCount || 0) + duplicateIds.length;
    primary.priorityScore = Math.min(100, (primary.priorityScore || 50) + (duplicateIds.length * 3));
    primary.statusHistory.push({
      status: primary.status,
      timestamp: now,
      note: `Merged ${duplicateIds.length} duplicate report(s) (${duplicateIds.join(', ')}). Total citizen impact boosted to ${primary.upvotes} supporters.`,
      updatedBy: 'Admin Duplicate Resolver'
    });
    primary.updatedAt = now;

    this.saveIssues(issues);
    return primary;
  }

  resetDemo() {
    this.saveIssues(seedIssues);
    return seedIssues;
  }
}

export default new StorageService();
