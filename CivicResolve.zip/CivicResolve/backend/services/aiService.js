/**
 * AI-powered issue classification, urgency detection, and department routing.
 * Incorporates intelligent NLP heuristics with optional Google Gemini API support.
 */

export class AIService {
  constructor() {
    this.geminiApiKey = process.env.GEMINI_API_KEY || null;
  }

  /**
   * Analyze issue details (title, description, location)
   */
  async analyzeIssue({ title = '', description = '', userCategory = '', location = {} }) {
    // If Gemini API Key is configured, attempt LLM call
    if (this.geminiApiKey) {
      try {
        const geminiResult = await this.callGeminiAPI(title, description, userCategory);
        if (geminiResult) return geminiResult;
      } catch (err) {
        console.warn('[AI Service] Gemini API call failed, falling back to local NLP engine:', err.message);
      }
    }

    // Default intelligent local NLP triage engine
    return this.localTriageEngine(title, description, userCategory, location);
  }

  localTriageEngine(title = '', description = '', userCategory = '', location = {}) {
    const text = `${title} ${description}`.toLowerCase();

    // 1. Category and Subcategory Matching Rules
    let category = "Roads & Infrastructure";
    let subcategory = "General Pavement Concern";
    let department = "Department of Public Works & Highways";
    let urgency = "Medium";
    let urgencyReason = "Standard civic maintenance request.";
    let safetyHazard = false;
    let safetyHazardDetails = null;
    let inspectionChecklist = [
      "Inspect reported location",
      "Assess structural severity",
      "Deploy field repair unit"
    ];

    // Critical Hazard Keywords
    const hasElectricalHazard = /wire|spark|electrocute|shock|live cable|high voltage|transformer/i.test(text);
    const hasSinkholeOrCaveIn = /sinkhole|cave-in|collapse|collapsing|crater|open manhole|missing manhole|subterranean/i.test(text);
    const hasBurstPipe = /water main|burst|gushing|flooding|spewing|water leak|broken pipe|sewer overflow|raw sewage/i.test(text);
    const hasGasOrChemical = /gas leak|chemical|toxic|fumes|hazardous waste|flammable|explosion/i.test(text);
    const hasTrafficLightDead = /traffic light|traffic signal|blacked out|signals down|intersection dead|near miss/i.test(text);

    // Categories Matching
    if (hasElectricalHazard || /streetlight|street light|light pole|lamp|bulb out|dark street|luminaire/i.test(text)) {
      category = "Streetlights & Electrical";
      department = "Municipal Energy & Street Lighting";
      if (hasElectricalHazard) {
        subcategory = "Exposed Electrical Hazard";
        urgency = "Critical";
        urgencyReason = "Exposed or sparking electrical wiring poses immediate risk of electrocution to pedestrians.";
        safetyHazard = true;
        safetyHazardDetails = "Immediate shock hazard. High danger zone for pedestrian traffic.";
        inspectionChecklist = [
          "De-energize feeder circuit immediately",
          "Deploy danger perimeter tape",
          "Inspect junction box and terminate conductors"
        ];
      } else {
        subcategory = "Streetlight Outage";
        urgency = /school|hospital|blind corner|crosswalk/i.test(text) ? "High" : "Medium";
        urgencyReason = urgency === "High"
          ? "Unlit pedestrian zone in high-activity or sensitive public area."
          : "Street illumination outage causing reduced night-time visibility.";
        inspectionChecklist = [
          "Test photo-electric controller",
          "Check LED driver and bulb continuity",
          "Restore luminaire operation"
        ];
      }
    } else if (hasBurstPipe || /drain|drainage|gutter|sewage|stormwater|stagnant water|puddle|catch basin/i.test(text)) {
      category = "Water Supply & Drainage";
      department = "Water & Sewage Authority";
      if (/raw sewage|foul|backflow/i.test(text) || (hasBurstPipe && /flooding|gushing|rapid/i.test(text))) {
        subcategory = hasBurstPipe ? "Water Main Rupture" : "Sewage Contamination";
        urgency = "Critical";
        urgencyReason = "Substantial pressurized water loss with risk of foundation undermining and water damage.";
        safetyHazard = true;
        safetyHazardDetails = "Ground subsidence threat and potential clean water contamination.";
        inspectionChecklist = [
          "Locate and isolate municipal distribution valve",
          "Coordinate emergency excavation crew",
          "Test soil moisture and repair pipeline"
        ];
      } else {
        subcategory = "Blocked Drain / Surface Water";
        urgency = /flooding|store|home|damage/i.test(text) ? "High" : "Medium";
        urgencyReason = "Stormwater drainage obstruction causing localized standing water.";
        inspectionChecklist = [
          "Clear debris and foliage from grate",
          "Hydro-jet storm sewer connection",
          "Verify downstream flow rate"
        ];
      }
    } else if (/tree|branch|limb|park|playground|bench|grass|bush|overgrown|swing|slide/i.test(text)) {
      category = "Public Parks & Trees";
      department = "Parks & Recreation Forestry Dept";
      if (/playground|slide|swing|child|injur/i.test(text)) {
        subcategory = "Playground Equipment Safety";
        urgency = "High";
        urgencyReason = "Damaged public recreation apparatus in active children's zone.";
        safetyHazard = true;
        safetyHazardDetails = "Risk of laceration or fall injury for children.";
        inspectionChecklist = [
          "Secure and barrier-off unsafe equipment",
          "Document damage dimensions and structural fatigue",
          "Replace damaged assembly components"
        ];
      } else if (/fallen|blocking|crushed|wires|traffic/i.test(text)) {
        subcategory = "Fallen Tree / Heavy Limb";
        urgency = "High";
        urgencyReason = "Downed tree limbs blocking transit lanes or pedestrian pathways.";
        inspectionChecklist = [
          "Cordon off transit lane",
          "Section and chip fallen timber",
          "Inspect canopy for remaining deadwood"
        ];
      } else {
        subcategory = "Parks Maintenance & Grounds";
        urgency = "Low";
        urgencyReason = "General park beautification and landscape maintenance.";
      }
    } else if (hasTrafficLightDead || /traffic|speed sign|signal|jam|crosswalk|pedestrian crossing|encroach|illegal park/i.test(text)) {
      category = "Traffic & Encroachment";
      department = "Transportation & Traffic Engineering";
      if (hasTrafficLightDead) {
        subcategory = "Traffic Signal Outage";
        urgency = "Critical";
        urgencyReason = "Dead signals at multi-way intersection generate immediate multi-vehicle crash risk.";
        safetyHazard = true;
        safetyHazardDetails = "Unregulated intersection traffic flow; extreme collision hazard.";
        inspectionChecklist = [
          "Deploy traffic police for manual intersection control",
          "Test signal control cabinet UPS backup",
          "Reset or replace conflict monitor unit"
        ];
      } else {
        subcategory = "Traffic Signs & Marking";
        urgency = /speed|stop sign|yield|school/i.test(text) ? "High" : "Low";
        urgencyReason = urgency === "High" ? "Missing or damaged regulatory signage." : "Minor signage issue.";
      }
    } else if (/garbage|trash|dump|waste|litter|bin|dumpster|smell|odor|vermin|rats|refuse/i.test(text)) {
      category = "Sanitation & Waste";
      department = "Municipal Solid Waste Management";
      subcategory = "Waste Collection & Overflow";
      urgency = /fire|rats|vermin|hospital|rotten|toxic/i.test(text) ? "High" : "Medium";
      urgencyReason = "Excessive uncollected waste causing public sanitation and vermin propagation risks.";
      inspectionChecklist = [
        "Deploy heavy waste collection truck",
        "Sanitize surface area with anti-bacterial spray",
        "Verify collection schedule adherence"
      ];
    } else if (/pothole|road|asphalt|sidewalk|pavement|curb|manhole|gravel|concrete/i.test(text)) {
      category = "Roads & Infrastructure";
      department = "Department of Public Works & Highways";
      if (hasSinkholeOrCaveIn || /open manhole|missing cover|flipping/i.test(text)) {
        subcategory = "Manhole / Road Cave-in";
        urgency = "Critical";
        urgencyReason = "Uncovered road opening or cave-in can swallow vehicle wheels or pedestrians.";
        safetyHazard = true;
        safetyHazardDetails = "Subterranean cavity opening into active traffic lane.";
        inspectionChecklist = [
          "Cover opening with heavy steel road plate immediately",
          "Check underground storm/sewer collar alignment",
          "Pour reinforced collar and secure bolted frame"
        ];
      } else if (/tire|rim|deep|blowout|bike|wheel|accident/i.test(text)) {
        subcategory = "Severe Road Pothole";
        urgency = "High";
        urgencyReason = "Deep road cavity actively causing vehicular damage and high accident probability.";
        safetyHazard = true;
        safetyHazardDetails = "Tire blowout and motorcycle steering loss hazard.";
        inspectionChecklist = [
          "Place reflective warning pylons 50m before site",
          "Square off damaged asphalt perimeter",
          "Fill with hot asphalt mix and mechanical roller compaction"
        ];
      } else {
        subcategory = "Pothole & Surface Wear";
        urgency = "Medium";
        urgencyReason = "Surface road degradation needing scheduled patch maintenance.";
        inspectionChecklist = [
          "Log dimensions and severity grade",
          "Schedule into weekly patch repair itinerary"
        ];
      }
    } else if (/graffiti|vandalism|noise|fumes|stray/i.test(text)) {
      category = "Public Safety & Health";
      department = "Public Health & Sanitation Bureau";
      subcategory = "Civic Nuisance & Maintenance";
      urgency = "Low";
      urgencyReason = "Community cleanliness and aesthetic upkeep item.";
    }

    // Respect user category if provided and valid
    if (userCategory && userCategory !== 'All' && userCategory !== category) {
      // Keep urgency & hazard analysis, but respect citizen chosen category if suitable
      category = userCategory;
    }

    // SLA & Priority score computation
    let estimatedResolutionHours = 48;
    let priorityScore = 65;

    if (urgency === "Critical") {
      estimatedResolutionHours = 8;
      priorityScore = Math.floor(92 + Math.random() * 7); // 92 - 99
    } else if (urgency === "High") {
      estimatedResolutionHours = 24;
      priorityScore = Math.floor(78 + Math.random() * 10); // 78 - 87
    } else if (urgency === "Medium") {
      estimatedResolutionHours = 48;
      priorityScore = Math.floor(58 + Math.random() * 12); // 58 - 70
    } else {
      estimatedResolutionHours = 96;
      priorityScore = Math.floor(35 + Math.random() * 15); // 35 - 50
    }

    return {
      category,
      subcategory,
      urgency,
      urgencyReason,
      department,
      estimatedResolutionHours,
      priorityScore,
      safetyHazard,
      safetyHazardDetails,
      inspectionChecklist,
      suggestedCitizenResponse: `Thank you for alerting the city. Our AI triage system categorized this as a ${urgency.toUpperCase()} priority issue and dispatched a notification to the ${department}.`,
      confidenceScore: 0.94
    };
  }

  async callGeminiAPI(title, description, userCategory) {
    const prompt = `You are CivicResolve's municipal AI triage engine. Analyze this citizen complaint:
Title: "${title}"
Description: "${description}"
User Category Hint: "${userCategory || 'Not specified'}"

Respond ONLY with valid JSON in this exact structure:
{
  "category": "Roads & Infrastructure" | "Sanitation & Waste" | "Streetlights & Electrical" | "Water Supply & Drainage" | "Public Parks & Trees" | "Traffic & Encroachment" | "Public Safety & Health",
  "subcategory": "short descriptive issue type",
  "urgency": "Critical" | "High" | "Medium" | "Low",
  "urgencyReason": "1-2 sentence explanation of urgency rationale",
  "department": "Department of Public Works & Highways" | "Municipal Solid Waste Management" | "Municipal Energy & Street Lighting" | "Water & Sewage Authority" | "Parks & Recreation Forestry Dept" | "Transportation & Traffic Engineering" | "Public Health & Sanitation Bureau",
  "estimatedResolutionHours": number,
  "priorityScore": number (1-100),
  "safetyHazard": boolean,
  "safetyHazardDetails": "string or null",
  "inspectionChecklist": ["step 1", "step 2", "step 3"],
  "suggestedCitizenResponse": "polite official notification string",
  "confidenceScore": number (0.0 to 1.0)
}`;

    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${this.geminiApiKey}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json" }
      })
    });

    if (!res.ok) {
      throw new Error(`Gemini API returned status ${res.status}`);
    }

    const data = await res.json();
    const textOutput = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (textOutput) {
      return JSON.parse(textOutput);
    }
    return null;
  }
}

export default new AIService();
