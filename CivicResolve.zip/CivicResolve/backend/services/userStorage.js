import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

// Default initial seed users with securely hashed passwords
const createInitialSeedUsers = () => {
  const saltRounds = 10;
  return [
    {
      id: "USR-001",
      name: "Marcus Vance",
      email: "admin@civicresolve.gov",
      passwordHash: bcrypt.hashSync("Admin@1234", saltRounds),
      role: "admin",
      department: "Municipal Administration & Oversight",
      phone: "+1 (555) 019-2834",
      createdAt: new Date().toISOString()
    },
    {
      id: "USR-002",
      name: "Sarah Jenkins",
      email: "staff@civicresolve.gov",
      passwordHash: bcrypt.hashSync("Staff@1234", saltRounds),
      role: "staff",
      department: "Department of Public Works & Highways",
      phone: "+1 (555) 019-5821",
      createdAt: new Date().toISOString()
    },
    {
      id: "USR-003",
      name: "Elena Rostova",
      email: "citizen@example.com",
      passwordHash: bcrypt.hashSync("Citizen@1234", saltRounds),
      role: "citizen",
      department: "",
      phone: "+1 (555) 019-9942",
      createdAt: new Date().toISOString()
    }
  ];
};

class UserStorage {
  constructor() {
    this.ensureUsersFile();
  }

  ensureUsersFile() {
    try {
      const dir = path.dirname(USERS_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      if (!fs.existsSync(USERS_FILE)) {
        const initial = createInitialSeedUsers();
        this.saveUsers(initial);
        console.log(`[UserStorage] Initialized ${initial.length} authenticated seed accounts.`);
      } else {
        const raw = fs.readFileSync(USERS_FILE, 'utf-8');
        if (!raw.trim()) {
          const initial = createInitialSeedUsers();
          this.saveUsers(initial);
        }
      }
    } catch (err) {
      console.error('[UserStorage] Error ensuring users file:', err);
      const initial = createInitialSeedUsers();
      this.saveUsers(initial);
    }
  }

  loadUsers() {
    try {
      if (!fs.existsSync(USERS_FILE)) {
        this.ensureUsersFile();
      }
      const raw = fs.readFileSync(USERS_FILE, 'utf-8');
      return JSON.parse(raw);
    } catch (err) {
      console.error('[UserStorage] Error reading users:', err);
      return [];
    }
  }

  saveUsers(users) {
    try {
      fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
      return true;
    } catch (err) {
      console.error('[UserStorage] Error saving users:', err);
      return false;
    }
  }

  findByEmail(email) {
    if (!email) return null;
    const users = this.loadUsers();
    return users.find(u => u.email.toLowerCase() === email.toLowerCase().trim()) || null;
  }

  findById(id) {
    if (!id) return null;
    const users = this.loadUsers();
    return users.find(u => u.id === id) || null;
  }

  async createUser({ name, email, password, role = 'citizen', department = '', phone = '' }) {
    const users = this.loadUsers();

    // Guard: ensure no unauthorized admin creation via public signup
    // Only 'citizen', 'staff', 'admin' are valid roles
    const safeRole = (role === 'admin' || role === 'staff') ? role : 'citizen';

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const maxIdNum = users.reduce((acc, curr) => {
      const match = curr.id && curr.id.match(/^USR-(\d+)$/);
      if (match) {
        const num = parseInt(match[1], 10);
        return num > acc ? num : acc;
      }
      return acc;
    }, 3);

    const newUser = {
      id: `USR-${String(maxIdNum + 1).padStart(3, '0')}`,
      name: name.trim(),
      email: email.toLowerCase().trim(),
      passwordHash,
      role: safeRole,
      department: safeRole === 'staff' ? department : '',
      phone: phone.trim(),
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    this.saveUsers(users);
    return this.sanitizeUser(newUser);
  }

  async verifyPassword(plainPassword, passwordHash) {
    if (!plainPassword || !passwordHash) return false;
    return bcrypt.compare(plainPassword, passwordHash);
  }

  sanitizeUser(user) {
    if (!user) return null;
    const { passwordHash, ...safeUser } = user;
    return safeUser;
  }
}

export default new UserStorage();
