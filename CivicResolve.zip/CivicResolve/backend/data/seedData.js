// Seed data for CivicResolve with realistic coordinates (Austin / Metro City core)
// Center point: lat 30.2672, lng -97.7431

export const seedIssues = [
  {
    id: "CR-1001",
    title: "Severe deep pothole damaging car tires on Elm Street",
    description: "Large asphalt crater approximately 2 feet wide and 5 inches deep right after the 4th Ave intersection. At least two commuters suffered popped tires today. It is poorly lit at night and extremely dangerous for cyclists and motorcyclists.",
    category: "Roads & Infrastructure",
    subcategory: "Pothole & Cavity",
    location: {
      address: "412 Elm Street, Downtown Metro",
      latitude: 30.2685,
      longitude: -97.7420,
      landmark: "Opposite Downtown Public Library"
    },
    urgency: "High",
    urgencyReason: "Active vehicle damage hazard on arterial road with severe risk for two-wheelers in low visibility.",
    department: "Department of Public Works & Highways",
    status: "In Progress",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 36 * 3600 * 1000).toISOString(),
        note: "Citizen reported via web portal with photo evidence.",
        updatedBy: "Citizen: Elena Rostova"
      },
      {
        status: "In Review",
        timestamp: new Date(Date.now() - 28 * 3600 * 1000).toISOString(),
        note: "AI triage validated High urgency. Dispatched alert to Highway Maintenance unit.",
        updatedBy: "AI Dispatch Engine"
      },
      {
        status: "In Progress",
        timestamp: new Date(Date.now() - 14 * 3600 * 1000).toISOString(),
        note: "Crew #4 dispatched with asphalt patch vehicle. Temporary warning pylons positioned.",
        updatedBy: "Supervisor D. Miller"
      }
    ],
    priorityScore: 84,
    estimatedResolutionHours: 48,
    assignedOfficer: "Marcus Vance (Senior Road Inspector)",
    reportedBy: "Elena Rostova",
    contact: "elena.rostova@example.com",
    upvotes: 18,
    upvoterEmails: ["citizen1@example.com", "cycling_club@example.com", "mark.t@example.com"],
    imageUrl: "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "",
    resolutionImageUrl: "",
    duplicatesCount: 2,
    duplicateIds: ["CR-1011"],
    aiAnalysis: {
      category: "Roads & Infrastructure",
      subcategory: "Pothole & Cavity",
      urgency: "High",
      urgencyReason: "Active vehicle tire blowouts and cyclist safety hazard on primary corridor.",
      department: "Department of Public Works & Highways",
      safetyHazard: true,
      safetyHazardDetails: "Crater depth exceeding 4 inches creates instantaneous wheel rim structural failure risk.",
      inspectionChecklist: [
        "Deploy 3 reflective safety cones 50m upstream",
        "Inspect perimeter for water seepage and subsurface erosion",
        "Apply hot-mix asphalt compaction and seal edges"
      ],
      confidenceScore: 0.95
    },
    createdAt: new Date(Date.now() - 36 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 14 * 3600 * 1000).toISOString()
  },
  {
    id: "CR-1002",
    title: "Burst municipal water main flooding pedestrian walkway",
    description: "High pressure water pipe ruptured under the sidewalk near Oak Avenue. Clean water is spewing 4 feet into the air and eroding the sub-base beneath the curb. Pavement is already starting to buckle.",
    category: "Water Supply & Drainage",
    subcategory: "Water Main Leak",
    location: {
      address: "880 Oak Avenue, Riverdale District",
      latitude: 30.2710,
      longitude: -97.7455,
      landmark: "Near Riverdale Community Health Center"
    },
    urgency: "Critical",
    urgencyReason: "Continuous high-volume water loss with imminent risk of structural sinkhole collapse.",
    department: "Water & Sewage Authority",
    status: "In Progress",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 8 * 3600 * 1000).toISOString(),
        note: "Urgent citizen phone & portal report with live video snapshot.",
        updatedBy: "Citizen: Jamal Thorne"
      },
      {
        status: "In Progress",
        timestamp: new Date(Date.now() - 6 * 3600 * 1000).toISOString(),
        note: "Emergency valve shutdown crew arrived. Sectional isolation valve locked out.",
        updatedBy: "Operator S. Chen (Water Authority)"
      }
    ],
    priorityScore: 98,
    estimatedResolutionHours: 12,
    assignedOfficer: "Capt. Frank Morales (Rapid Emergency Response)",
    reportedBy: "Jamal Thorne",
    contact: "jamal.thorne@example.com",
    upvotes: 32,
    upvoterEmails: ["riverdale_resident@example.com", "clinic_admin@example.com"],
    imageUrl: "https://images.unsplash.com/photo-1541888946425-d0fbb186f5f8?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "",
    resolutionImageUrl: "",
    duplicatesCount: 1,
    duplicateIds: [],
    aiAnalysis: {
      category: "Water Supply & Drainage",
      subcategory: "Water Main Leak",
      urgency: "Critical",
      urgencyReason: "Massive pressurized water discharge threatening pedestrian foundation and street undermining.",
      department: "Water & Sewage Authority",
      safetyHazard: true,
      safetyHazardDetails: "Immediate risk of ground collapse / sinkhole under pedestrian traffic.",
      inspectionChecklist: [
        "Shut off section gate valve #W-204",
        "Excavate damaged 6-inch ductile iron main",
        "Replace damaged coupling and backfill aggregate"
      ],
      confidenceScore: 0.98
    },
    createdAt: new Date(Date.now() - 8 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 6 * 3600 * 1000).toISOString()
  },
  {
    id: "CR-1003",
    title: "Broken streetlight pole with sparking wires near primary school",
    description: "Streetlight fixture knocked loose during high winds, hanging precariously over the crosswalk. Wires are exposed and sparking intermittently when wind blows. Elementary school children use this exact crossing at 3 PM.",
    category: "Streetlights & Electrical",
    subcategory: "Exposed Electrical Hazard",
    location: {
      address: "155 West 9th Street, Midtown",
      latitude: 30.2742,
      longitude: -97.7478,
      landmark: "Crosswalk outside Midtown Elementary"
    },
    urgency: "Critical",
    urgencyReason: "Exposed live high-voltage wiring near a children's pedestrian school crosswalk.",
    department: "Municipal Energy & Street Lighting",
    status: "Reported",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
        note: "Reported by school crossing guard. High priority notification broadcast to energy grid team.",
        updatedBy: "Guard Teresa Gomez"
      }
    ],
    priorityScore: 96,
    estimatedResolutionHours: 6,
    assignedOfficer: "Pending Dispatch",
    reportedBy: "Teresa Gomez",
    contact: "teresa.gomez@midtownschools.edu",
    upvotes: 24,
    upvoterEmails: ["pta_president@example.com", "parent12@example.com"],
    imageUrl: "https://images.unsplash.com/photo-1508873696983-2df5293cb325?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "",
    resolutionImageUrl: "",
    duplicatesCount: 1,
    duplicateIds: ["CR-1012"],
    aiAnalysis: {
      category: "Streetlights & Electrical",
      subcategory: "Exposed Electrical Hazard",
      urgency: "Critical",
      urgencyReason: "Live voltage sparking hanging above school pedestrian path poses imminent electrocution hazard.",
      department: "Municipal Energy & Street Lighting",
      safetyHazard: true,
      safetyHazardDetails: "Live conductors sparking in public walkway.",
      inspectionChecklist: [
        "De-energize circuit loop 12B immediately",
        "Cordon off 20m perimeter with danger tape",
        "Replace luminaire fixture and terminate cables securely"
      ],
      confidenceScore: 0.99
    },
    createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString()
  },
  {
    id: "CR-1004",
    title: "Overflowing commercial dumpsters attracting rodents in alley",
    description: "Three commercial bins have not been emptied in 10 days behind Pine Street food court. Heaps of decomposing organic waste are blocking fire egress doors, generating severe foul odor, and attracting rats and stray animals.",
    category: "Sanitation & Waste",
    subcategory: "Illegal Dumping / Trash Overflow",
    location: {
      address: "240 Pine Street Alleyway, Market Square",
      latitude: 30.2650,
      longitude: -97.7405,
      landmark: "Behind Pine Plaza Food Court"
    },
    urgency: "Medium",
    urgencyReason: "Public health sanitation concern and fire escape pathway obstruction.",
    department: "Municipal Solid Waste Management",
    status: "In Progress",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
        note: "Business owner reported persistent trash collection failure.",
        updatedBy: "Citizen: Arthur Pendelton"
      },
      {
        status: "In Review",
        timestamp: new Date(Date.now() - 30 * 3600 * 1000).toISOString(),
        note: "Waste division notified commercial sanitation contractor for breach of SLA.",
        updatedBy: "Inspector R. Thorne"
      },
      {
        status: "In Progress",
        timestamp: new Date(Date.now() - 10 * 3600 * 1000).toISOString(),
        note: "Heavy compactor truck scheduled for priority clear-out at 2 PM.",
        updatedBy: "Route Coordinator"
      }
    ],
    priorityScore: 68,
    estimatedResolutionHours: 24,
    assignedOfficer: "Carlos Mendez (Sanitation Enforcement)",
    reportedBy: "Arthur Pendelton",
    contact: "arthur.p@pinemarket.com",
    upvotes: 11,
    upvoterEmails: ["merchant_association@example.com"],
    imageUrl: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "",
    resolutionImageUrl: "",
    duplicatesCount: 0,
    duplicateIds: [],
    aiAnalysis: {
      category: "Sanitation & Waste",
      subcategory: "Illegal Dumping / Trash Overflow",
      urgency: "Medium",
      urgencyReason: "Sanitation issue affecting public hygiene and blocking emergency exit.",
      department: "Municipal Solid Waste Management",
      safetyHazard: false,
      safetyHazardDetails: "Sanitation violation; minor fire escape clearance infringement.",
      inspectionChecklist: [
        "Deploy hydraulic compactor truck",
        "Sanitize and disinfect alley pavement",
        "Issue notice to property manager regarding bin capacity"
      ],
      confidenceScore: 0.92
    },
    createdAt: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 10 * 3600 * 1000).toISOString()
  },
  {
    id: "CR-1005",
    title: "Large fallen oak branch blocking bike lane and sidewalk",
    description: "A 15-foot limb from an ancient live oak snapped during the thunderstorm. It has completely blocked the westbound protected bike lane and crushed a section of pedestrian railing.",
    category: "Public Parks & Trees",
    subcategory: "Downed Trees & Forestry",
    location: {
      address: "620 Riverfront Boulevard, Riverwalk",
      latitude: 30.2625,
      longitude: -97.7460,
      landmark: "Near Riverwalk Pedestrian Bridge"
    },
    urgency: "Medium",
    urgencyReason: "Obstructed transit corridor causing bikes to veer into high speed vehicular traffic.",
    department: "Parks & Recreation Forestry Dept",
    status: "Resolved",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 72 * 3600 * 1000).toISOString(),
        note: "Cyclist reported obstruction via CivicResolve mobile web app.",
        updatedBy: "Citizen: Maya Lin"
      },
      {
        status: "In Progress",
        timestamp: new Date(Date.now() - 50 * 3600 * 1000).toISOString(),
        note: "Urban Forestry crew deployed with woodchippers and chainsaw squad.",
        updatedBy: "Forestry Supervisor K. Novak"
      },
      {
        status: "Resolved",
        timestamp: new Date(Date.now() - 18 * 3600 * 1000).toISOString(),
        note: "Tree limb sectioned, chipped into community mulch, sidewalk swept, railing repaired.",
        updatedBy: "Forestry Crew #2 Lead"
      }
    ],
    priorityScore: 62,
    estimatedResolutionHours: 24,
    assignedOfficer: "Lars Lindqvist (Urban Arborist)",
    reportedBy: "Maya Lin",
    contact: "maya.lin@bikemetro.org",
    upvotes: 19,
    upvoterEmails: ["cyclist_metro@example.com", "pedestrian_guild@example.com"],
    imageUrl: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "Hazard cleared. 1.2 tons of timber chipped. Pedestrian handrail welded and repainted.",
    resolutionImageUrl: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=800&q=80",
    duplicatesCount: 1,
    duplicateIds: [],
    aiAnalysis: {
      category: "Public Parks & Trees",
      subcategory: "Downed Trees & Forestry",
      urgency: "Medium",
      urgencyReason: "Obstruction of protected mobility lane requiring diversion into traffic.",
      department: "Parks & Recreation Forestry Dept",
      safetyHazard: false,
      safetyHazardDetails: "Non-fatal obstruction; traffic speed limit on adjacent road is 25mph.",
      inspectionChecklist: [
        "Section limb with chainsaws into 4-foot manageable lengths",
        "Inspect parent tree trunk for internal rot or secondary split risk",
        "Restore damaged safety bollards"
      ],
      confidenceScore: 0.94
    },
    createdAt: new Date(Date.now() - 72 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 18 * 3600 * 1000).toISOString()
  },
  {
    id: "CR-1006",
    title: "Loose iron manhole cover flipping when heavy buses pass",
    description: "The heavy storm sewer manhole cover on Maple Avenue has slipped off its seating ring. Whenever city buses or delivery trucks drive over it, the cover flips upward with a loud clang and creates a lethal opening.",
    category: "Roads & Infrastructure",
    subcategory: "Manhole / Grate Dislodged",
    location: {
      address: "310 Maple Avenue, Westside",
      latitude: 30.2702,
      longitude: -97.7490,
      landmark: "In front of Westside Bus Transit Stop #14"
    },
    urgency: "Critical",
    urgencyReason: "Unseated manhole cover on heavy transit route can cause rollover accidents or crush pedestrians.",
    department: "Department of Public Works & Highways",
    status: "Reported",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 3 * 3600 * 1000).toISOString(),
        note: "Bus driver radioed dispatch, citizen confirmed with high-res photo.",
        updatedBy: "Citizen: David K."
      }
    ],
    priorityScore: 95,
    estimatedResolutionHours: 8,
    assignedOfficer: "Pending Dispatch",
    reportedBy: "David K.",
    contact: "david.k@transitwest.org",
    upvotes: 27,
    upvoterEmails: ["transit_safety@example.com"],
    imageUrl: "https://images.unsplash.com/photo-1590486803833-1c5dc8ddd4c8?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "",
    resolutionImageUrl: "",
    duplicatesCount: 0,
    duplicateIds: [],
    aiAnalysis: {
      category: "Roads & Infrastructure",
      subcategory: "Manhole / Grate Dislodged",
      urgency: "Critical",
      urgencyReason: "A flipping manhole lid on bus route can shear vehicle axles and cause catastrophic derailment.",
      department: "Department of Public Works & Highways",
      safetyHazard: true,
      safetyHazardDetails: "Exposed subterranean drop of 14 feet; vehicular tire trap.",
      inspectionChecklist: [
        "Place heavy steel road plate over opening",
        "Clean asphalt buildup from rim seat",
        "Replace frame and gasket with self-locking lid"
      ],
      confidenceScore: 0.97
    },
    createdAt: new Date(Date.now() - 3 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 3600 * 1000).toISOString()
  },
  {
    id: "CR-1007",
    title: "Cracked children's spiral slide with jagged plastic edge",
    description: "The primary yellow spiral slide in Sunnydale Park playground has a 10-inch jagged fracture halfway down the descent. A 6-year-old child received a deep scrape yesterday. Needs immediate cordon.",
    category: "Public Parks & Trees",
    subcategory: "Playground Equipment Damage",
    location: {
      address: "710 Sunnydale Park Way, North Park",
      latitude: 30.2765,
      longitude: -97.7410,
      landmark: "Sunnydale Children's Playscape East"
    },
    urgency: "High",
    urgencyReason: "Sharp jagged plastic cutting edge in high-density toddler and child playground.",
    department: "Parks & Recreation Forestry Dept",
    status: "In Progress",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 20 * 3600 * 1000).toISOString(),
        note: "Parent reported with injury details.",
        updatedBy: "Citizen: Sandra Becker"
      },
      {
        status: "In Progress",
        timestamp: new Date(Date.now() - 12 * 3600 * 1000).toISOString(),
        note: "Park ranger applied temporary barrier tape and boarded entrance stairs.",
        updatedBy: "Ranger Tim O'Connor"
      }
    ],
    priorityScore: 81,
    estimatedResolutionHours: 24,
    assignedOfficer: "Brenda Vance (Playground Safety Inspector)",
    reportedBy: "Sandra Becker",
    contact: "sandra.b@example.com",
    upvotes: 21,
    upvoterEmails: ["parent_council@example.com"],
    imageUrl: "https://images.unsplash.com/photo-1575783970733-1aaedde1db74?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "",
    resolutionImageUrl: "",
    duplicatesCount: 0,
    duplicateIds: [],
    aiAnalysis: {
      category: "Public Parks & Trees",
      subcategory: "Playground Equipment Damage",
      urgency: "High",
      urgencyReason: "Laceration hazard for young children on public equipment.",
      department: "Parks & Recreation Forestry Dept",
      safetyHazard: true,
      safetyHazardDetails: "Sharp fractured edge in path of child sliding momentum.",
      inspectionChecklist: [
        "Board off slide top tower entrance",
        "Order replacement modular roto-molded chute",
        "Inspect surrounding swings and climbing ropes"
      ],
      confidenceScore: 0.96
    },
    createdAt: new Date(Date.now() - 20 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 12 * 3600 * 1000).toISOString()
  },
  {
    id: "CR-1008",
    title: "Obscene graffiti vandalism defacing historical war memorial",
    description: "Spray paint vandalism across the granite memorial wall in Memorial Park. Offensive slogans and tags covering the engraved names of veterans.",
    category: "Public Safety & Health",
    subcategory: "Vandalism & Graffiti",
    location: {
      address: "100 Memorial Plaza, Civic Center",
      latitude: 30.2660,
      longitude: -97.7445,
      landmark: "Veterans Memorial Wall"
    },
    urgency: "Low",
    urgencyReason: "Cosmetic damage on public monument; non-hazardous but sensitive civic priority.",
    department: "Public Health & Sanitation Bureau",
    status: "Resolved",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 96 * 3600 * 1000).toISOString(),
        note: "Citizen reported morning discovery.",
        updatedBy: "Citizen: Robert Hayes"
      },
      {
        status: "In Progress",
        timestamp: new Date(Date.now() - 70 * 3600 * 1000).toISOString(),
        note: "Restoration team deployed eco-friendly citrus solvent and low-pressure steam washer.",
        updatedBy: "Restoration Tech Al"
      },
      {
        status: "Resolved",
        timestamp: new Date(Date.now() - 40 * 3600 * 1000).toISOString(),
        note: "Graffiti completely removed without damaging granite patina. Protective anti-graffiti coating applied.",
        updatedBy: "Director of Civic Assets"
      }
    ],
    priorityScore: 45,
    estimatedResolutionHours: 48,
    assignedOfficer: "Hassan Al-Mansoor",
    reportedBy: "Robert Hayes",
    contact: "rhayes@veteransmetro.org",
    upvotes: 35,
    upvoterEmails: ["citizens_pride@example.com"],
    imageUrl: "https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "Fully stripped with bio-degradable solution and pressure wash. Anti-graffiti sacrificial seal applied.",
    resolutionImageUrl: "https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=800&q=80",
    duplicatesCount: 0,
    duplicateIds: [],
    aiAnalysis: {
      category: "Public Safety & Health",
      subcategory: "Vandalism & Graffiti",
      urgency: "Low",
      urgencyReason: "Aesthetic / community harm without physical structural danger.",
      department: "Public Health & Sanitation Bureau",
      safetyHazard: false,
      safetyHazardDetails: "Non-toxic paint vandalism on masonry.",
      inspectionChecklist: [
        "Test stone porosity before chemical wash",
        "Wash with heated DI water and low PSI nozzle",
        "Coat with siliconized anti-vandalism clear coat"
      ],
      confidenceScore: 0.93
    },
    createdAt: new Date(Date.now() - 96 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 40 * 3600 * 1000).toISOString()
  },
  {
    id: "CR-1009",
    title: "Traffic signal lights completely blacked out at busy 4-way junction",
    description: "The 4-way traffic signals at Congress Ave & 6th St are totally dead following a transformer spike. Cars are entering the intersection simultaneously, near miss accidents happening every few minutes. Gridlock forming.",
    category: "Traffic & Encroachment",
    subcategory: "Traffic Light Malfunction",
    location: {
      address: "600 Congress Avenue, Downtown",
      latitude: 30.2680,
      longitude: -97.7428,
      landmark: "Intersection of 6th & Congress"
    },
    urgency: "Critical",
    urgencyReason: "Major downtown arterial intersection with zero traffic control signals.",
    department: "Transportation & Traffic Engineering",
    status: "In Progress",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 1 * 3600 * 1000).toISOString(),
        note: "Multiple 911 transfer reports and automated grid sensor alert.",
        updatedBy: "Citizen: Liam Ward"
      },
      {
        status: "In Progress",
        timestamp: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
        note: "Traffic police deployed for manual traffic direction. Signal technician on site resetting logic controller.",
        updatedBy: "Traffic Operations Officer J. Ruiz"
      }
    ],
    priorityScore: 99,
    estimatedResolutionHours: 4,
    assignedOfficer: "Sgt. Javier Ruiz (Traffic Command)",
    reportedBy: "Liam Ward",
    contact: "liam.ward@austincommuter.com",
    upvotes: 46,
    upvoterEmails: ["downtown_alliance@example.com"],
    imageUrl: "https://images.unsplash.com/photo-1545459720-aac8509eb02c?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "",
    resolutionImageUrl: "",
    duplicatesCount: 3,
    duplicateIds: [],
    aiAnalysis: {
      category: "Traffic & Encroachment",
      subcategory: "Traffic Light Malfunction",
      urgency: "Critical",
      urgencyReason: "Mass collision hazard in central downtown business corridor.",
      department: "Transportation & Traffic Engineering",
      safetyHazard: true,
      safetyHazardDetails: "Immediate risk of multi-vehicle broadside crashes.",
      inspectionChecklist: [
        "Deploy traffic control officers immediately",
        "Inspect electrical cabinet breaker #CB-4",
        "Replace failed MMU (Malfunction Management Unit)"
      ],
      confidenceScore: 0.99
    },
    createdAt: new Date(Date.now() - 1 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 40 * 60 * 1000).toISOString()
  },
  {
    id: "CR-1010",
    title: "Clogged storm drain causing massive street ponding after rain",
    description: "Storm drain inlet on 3rd & Cedar is completely choked with autumn leaves and construction sediment. 8 inches of stagnant water is flooding the curb and creeping into ground-floor storefront doorways.",
    category: "Water Supply & Drainage",
    subcategory: "Blocked Drain / Flooding",
    location: {
      address: "305 Cedar Street, Downtown",
      latitude: 30.2668,
      longitude: -97.7465,
      landmark: "Corner of Cedar & 3rd St"
    },
    urgency: "Medium",
    urgencyReason: "Localized flooding threatening commercial property entrances and pedestrian accessibility.",
    department: "Water & Sewage Authority",
    status: "Reported",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 15 * 3600 * 1000).toISOString(),
        note: "Store owner submitted report with photos of rising water level.",
        updatedBy: "Citizen: Chloe Martin"
      }
    ],
    priorityScore: 66,
    estimatedResolutionHours: 24,
    assignedOfficer: "Pending Dispatch",
    reportedBy: "Chloe Martin",
    contact: "chloe@cedarboutique.com",
    upvotes: 8,
    upvoterEmails: [],
    imageUrl: "https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "",
    resolutionImageUrl: "",
    duplicatesCount: 0,
    duplicateIds: [],
    aiAnalysis: {
      category: "Water Supply & Drainage",
      subcategory: "Blocked Drain / Flooding",
      urgency: "Medium",
      urgencyReason: "Standing water accumulation causing property ingress hindrance and mosquito breeding.",
      department: "Water & Sewage Authority",
      safetyHazard: false,
      safetyHazardDetails: "No open sinkhole; pedestrian pathway drowned in 6-8 inches of stormwater.",
      inspectionChecklist: [
        "Vactor vacuum truck to clear leaf compost and gravel",
        "Jet sewer line to downstream manhole",
        "Inspect catch basin baffle"
      ],
      confidenceScore: 0.91
    },
    createdAt: new Date(Date.now() - 15 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 15 * 3600 * 1000).toISOString()
  },
  // Issue 11: A realistic duplicate of CR-1001 nearby!
  {
    id: "CR-1011",
    title: "Dangerous pothole near library on Elm St broke my wheel",
    description: "Deep tire-eating pothole right near the library on Elm. Blew out my rim this morning! Needs to be fixed before somebody on a scooter gets killed.",
    category: "Roads & Infrastructure",
    subcategory: "Pothole & Cavity",
    location: {
      address: "440 Elm Street, Downtown Metro",
      latitude: 30.2687,
      longitude: -97.7422,
      landmark: "Adjacent to Downtown Library"
    },
    urgency: "High",
    urgencyReason: "High-risk pothole on Elm St causing wheel rim damages.",
    department: "Department of Public Works & Highways",
    status: "In Progress",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 22 * 3600 * 1000).toISOString(),
        note: "Citizen reported. AI detected 93% duplicate match to #CR-1001.",
        updatedBy: "Citizen: Lucas Vance"
      },
      {
        status: "In Progress",
        timestamp: new Date(Date.now() - 14 * 3600 * 1000).toISOString(),
        note: "Linked as duplicate of primary incident #CR-1001. Crew working on site.",
        updatedBy: "Supervisor D. Miller"
      }
    ],
    priorityScore: 82,
    estimatedResolutionHours: 48,
    assignedOfficer: "Marcus Vance",
    reportedBy: "Lucas Vance",
    contact: "lucas.v@example.com",
    upvotes: 9,
    upvoterEmails: [],
    imageUrl: "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "",
    resolutionImageUrl: "",
    duplicatesCount: 0,
    duplicateIds: [],
    aiAnalysis: {
      category: "Roads & Infrastructure",
      subcategory: "Pothole & Cavity",
      urgency: "High",
      urgencyReason: "Deep cavity in roadway causing vehicle damage.",
      department: "Department of Public Works & Highways",
      safetyHazard: true,
      safetyHazardDetails: "Tire and rim puncture hazard.",
      inspectionChecklist: ["Verify repair along Elm Street sector 4"],
      confidenceScore: 0.94
    },
    createdAt: new Date(Date.now() - 22 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 14 * 3600 * 1000).toISOString()
  },
  // Issue 12: Streetlight outage near CR-1003
  {
    id: "CR-1012",
    title: "Street lamp out and wires loose on 9th St",
    description: "Light pole near the school crosswalk is pitch black and fixture has loose dangling wires.",
    category: "Streetlights & Electrical",
    subcategory: "Exposed Electrical Hazard",
    location: {
      address: "160 West 9th Street, Midtown",
      latitude: 30.2743,
      longitude: -97.7479,
      landmark: "Near school entrance"
    },
    urgency: "Critical",
    urgencyReason: "Exposed wiring and darkness at school crossing.",
    department: "Municipal Energy & Street Lighting",
    status: "Reported",
    statusHistory: [
      {
        status: "Reported",
        timestamp: new Date(Date.now() - 1 * 3600 * 1000).toISOString(),
        note: "AI detected 91% proximity & description similarity to #CR-1003.",
        updatedBy: "Citizen: Rachel Green"
      }
    ],
    priorityScore: 94,
    estimatedResolutionHours: 6,
    assignedOfficer: "Pending Dispatch",
    reportedBy: "Rachel Green",
    contact: "rachel.g@example.com",
    upvotes: 5,
    upvoterEmails: [],
    imageUrl: "https://images.unsplash.com/photo-1508873696983-2df5293cb325?auto=format&fit=crop&w=800&q=80",
    resolutionNote: "",
    resolutionImageUrl: "",
    duplicatesCount: 0,
    duplicateIds: [],
    aiAnalysis: {
      category: "Streetlights & Electrical",
      subcategory: "Exposed Electrical Hazard",
      urgency: "Critical",
      urgencyReason: "Live loose electrical wiring near crosswalk.",
      department: "Municipal Energy & Street Lighting",
      safetyHazard: true,
      safetyHazardDetails: "Electrocution hazard.",
      inspectionChecklist: ["Coordinate with crew already dispatched for CR-1003"],
      confidenceScore: 0.97
    },
    createdAt: new Date(Date.now() - 1 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 3600 * 1000).toISOString()
  }
];
